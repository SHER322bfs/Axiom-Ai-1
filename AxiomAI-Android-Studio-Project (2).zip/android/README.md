# Axiom AI — Personal Offline-First Android Assistant

Axiom AI is a personal, fully offline-first AI assistant built specifically for Android with Kotlin, Jetpack Compose Material 3, Android NDK (CMake + C++ JNI), and SQLite local persistence (Room).

Optimized specifically for the **Vivo V25** (MediaTek Dimensity 1300, 8-Core ARM64 Cortex-A78/A55, 8 GB RAM, 128 GB Storage).

---

## 1. Feature Status & Verification Checklist

| Feature | Status | Engineering Detail |
| :--- | :--- | :--- |
| **App Installation & Compose UI** | **WORKING** | Jetpack Compose Material 3, dark obsidian `#0B0D13` palette, edge-to-edge support. |
| **GGUF Import via SAF** | **WORKING** | Android `ACTION_OPEN_DOCUMENT` file picker, copies to `/files/models/` with verification. |
| **GGUF Magic Byte Validation** | **WORKING** | Inspects binary header for `0x46554747` (`GGUF`), detects version and tensor counts. |
| **Model Activation & Unload** | **WORKING** | Loads weights into active memory, unloads cleanly, checks available RAM before loading. |
| **Local llama.cpp C++ Engine** | **WORKING** | C++ JNI bridge (`llama-jni.cpp`) with `-march=armv8-a+fp16+dotprod` compiler flags. |
| **Streaming Token Generation** | **WORKING** | Token-by-token streaming flow directly to Compose chat bubble. |
| **Stop Generation Button** | **WORKING** | Atomic cancellation flag halts generation immediately when tapped. |
| **English Voice Input** | **WORKING** | Android `SpeechRecognizer` (`en-IN` / `en-US`) with live RMS audio waveform. |
| **Hindi & Hinglish Voice Input**| **WORKING** | Multilingual speech intent with `hi-IN` and Hinglish recognition support. |
| **Offline Voice Output (TTS)** | **WORKING** | Android `TextToSpeech` with auto-language detection, speed control, and markdown stripping. |
| **Wake Word System** | **WORKING** | Acoustic energy analyzer + `WakeWordService` foreground service with persistent notification. |
| **App Launching (Chrome, etc.)** | **WORKING** | `PackageManager` queries with `<queries>` visibility declarations for Android 11+. |
| **Phone Settings Controller** | **WORKING** | Standard Android settings intents (`ACTION_WIFI_SETTINGS`, `ACTION_BLUETOOTH_SETTINGS`, etc.). |
| **Alarms & Reminders** | **WORKING** | `AlarmClock.ACTION_SET_ALARM` with label and time parameters. |
| **Phone Calls** | **WORKING** | Launches `Intent.ACTION_DIAL`. Does not silently place calls without user approval. |
| **WhatsApp / Telegram Messenger**| **WORKING** | Formats intents with pre-filled text. |
| **Safety Confirmation Dialog** | **WORKING** | **MANDATORY**: Displays modal with channel, recipient, and message before dispatching. |
| **Notification Reader** | **WORKING** | `AxiomNotificationListener` captures authorized incoming notifications for summary. |
| **Hybrid Mode / Weather** | **WORKING** | Toggleable online lookup without requiring any paid API keys. |
| **Unrestricted 24/7 Background Mic**| **BLOCKED BY ANDROID**| Android 12+ restricts background mic recording when app is backgrounded unless running as an active user-visible foreground service. Handled via `WakeWordService` + Push-to-Talk. |

---

## 2. Beginner Step-by-Step Build Instructions

### Prerequisites
- Install **Android Studio** (Ladybug 2024.2+ or newer) on your computer.
- Ensure Android SDK 35 and NDK (version 26+ or 27+) are installed via Android Studio SDK Manager.

### Building the APK
1. Open Android Studio.
2. Select **File > Open...** and navigate to this `android/` directory.
3. Allow Gradle to sync dependencies automatically.
4. Connect your **Vivo V25** phone to your computer via USB:
   - Go to phone **Settings > About Phone > Software Information**.
   - Tap **Build Number** 7 times to enable Developer Options.
   - Go to **Settings > System > Developer Options** and enable **USB Debugging**.
5. In Android Studio, select your Vivo V25 in the device drop-down.
6. Click the green **Run (▶)** button (or press `Shift + F10`).
7. Android Studio will compile the C++ NDK library (`libaxiom_llama.so`), build the APK, and install it on your phone!

### Command-Line Build (Terminal)
```bash
# Build installable debug APK
./gradlew assembleDebug

# Output APK path:
# app/build/outputs/apk/debug/app-debug.apk

# Install directly to your connected Vivo V25
./gradlew installDebug
```

---

## 3. How to Download & Import a Compatible GGUF Model

For the Vivo V25 (MediaTek Dimensity 1300 with 8GB RAM), small 1B-2B models quantized to **Q4_K_M** offer the best combination of speed, reasoning, and thermal efficiency.

### Recommended Models:
1. **Qwen 2.5 1.5B Instruct (Q4_K_M)** ~ 986 MB  
   *Outstanding multilingual capability, excellent Hindi and English comprehension.*  
   Download link: [HuggingFace - Qwen 2.5 1.5B Instruct GGUF](https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF)
2. **Llama 3.2 1B Instruct (Q4_K_M)** ~ 770 MB  
   *Ultra-fast, lowest memory footprint.*  
   Download link: [HuggingFace - Llama 3.2 1B Instruct GGUF](https://huggingface.co/bartowski/Llama-3.2-1B-Instruct-GGUF)

### Importing to Axiom AI on your phone:
1. Download the `.gguf` file in your phone's browser (e.g. Chrome) into your `Downloads` folder.
2. Open **Axiom AI**.
3. Tap the **Settings** gear icon (top right) > Tap **Open Model Manager (GGUF)**.
4. Tap **Select GGUF File**.
5. Pick the downloaded `.gguf` file from your Downloads.
6. Axiom AI will validate the GGUF header signature and copy it into the app's secure private directory.
7. Tap **Load Model** to activate it!
