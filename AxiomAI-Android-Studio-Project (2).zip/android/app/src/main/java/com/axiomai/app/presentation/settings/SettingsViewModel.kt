package com.axiomai.app.presentation.settings

import android.content.Context
import android.os.Build
import android.os.PowerManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.axiomai.app.data.repository.ChatRepository
import com.axiomai.app.domain.engine.LocalLlmEngine
import com.axiomai.app.domain.engine.ModelEngineConfig
import com.axiomai.app.domain.engine.ModelStatus
import com.axiomai.app.domain.voice.VoiceInputManager
import com.axiomai.app.domain.voice.VoiceOutputManager
import com.axiomai.app.domain.voice.WakeWordManager
import com.axiomai.app.domain.voice.WakeWordState
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class SettingsUiEvent {
    data class ShowToast(val message: String) : SettingsUiEvent()
}

data class PermissionStatus(
    val hasAudioPermission: Boolean,
    val hasNotificationPermission: Boolean,
    val isBatteryOptimizedIgnored: Boolean
)

class SettingsViewModel(
    private val repository: ChatRepository,
    private val llmEngine: LocalLlmEngine,
    val voiceInputManager: VoiceInputManager,
    val voiceOutputManager: VoiceOutputManager,
    val wakeWordManager: WakeWordManager
) : ViewModel() {

    val modelStatus: StateFlow<ModelStatus> = llmEngine.modelStatus
    val engineConfig: StateFlow<ModelEngineConfig> = llmEngine.config
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = ModelEngineConfig()
        )

    val wakeWordState: StateFlow<WakeWordState> = wakeWordManager.state
    val currentWakeWord: StateFlow<String> = wakeWordManager.wakeWord
    val ttsRate: StateFlow<Float> = voiceOutputManager.speechRate
    val isOfflineSpeechSupported: StateFlow<Boolean> = voiceInputManager.isOfflineSupported

    private val _permissions = MutableStateFlow(
        PermissionStatus(hasAudioPermission = false, hasNotificationPermission = false, isBatteryOptimizedIgnored = false)
    )
    val permissions: StateFlow<PermissionStatus> = _permissions.asStateFlow()

    private val _uiEvents = MutableSharedFlow<SettingsUiEvent>()
    val uiEvents = _uiEvents.asSharedFlow()

    fun checkPermissions(context: Context) {
        val hasAudio = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.RECORD_AUDIO
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED

        val hasNotif = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        } else {
            true
        }

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val isIgnored = powerManager.isIgnoringBatteryOptimizations(context.packageName)

        _permissions.value = PermissionStatus(hasAudio, hasNotif, isIgnored)
    }

    fun updateCpuThreads(threads: Int) {
        val current = engineConfig.value
        llmEngine.updateConfig(current.copy(nThreads = threads))
    }

    fun updateContextSize(contextSize: Int) {
        val current = engineConfig.value
        llmEngine.updateConfig(current.copy(contextSize = contextSize))
    }

    fun setSpeechRate(rate: Float) {
        voiceOutputManager.setSpeechRate(rate)
    }

    fun testSpeech() {
        voiceOutputManager.speak("Axiom AI offline voice output is ready on your device.")
    }

    fun clearChatHistory() {
        viewModelScope.launch {
            repository.clearHistory()
            _uiEvents.emit(SettingsUiEvent.ShowToast("All conversation history cleared from SQLite"))
        }
    }
}
