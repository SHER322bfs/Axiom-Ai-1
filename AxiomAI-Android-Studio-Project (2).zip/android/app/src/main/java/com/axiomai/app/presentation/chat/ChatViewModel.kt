package com.axiomai.app.presentation.chat

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.axiomai.app.data.local.ChatMessageEntity
import com.axiomai.app.data.local.MessageSender
import com.axiomai.app.data.repository.ChatRepository
import com.axiomai.app.domain.engine.LlmEngine
import com.axiomai.app.domain.engine.ModelStatus
import com.axiomai.app.domain.tools.PendingConfirmation
import com.axiomai.app.domain.tools.ToolRegistry
import com.axiomai.app.domain.voice.VoiceInputManager
import com.axiomai.app.domain.voice.VoiceInputState
import com.axiomai.app.domain.voice.VoiceOutputManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class ChatUiEvent {
    data class ShowToast(val message: String) : ChatUiEvent()
}

class ChatViewModel(
    private val repository: ChatRepository,
    private val llmEngine: LlmEngine,
    val voiceInputManager: VoiceInputManager,
    val voiceOutputManager: VoiceOutputManager,
    private val toolRegistry: ToolRegistry
) : ViewModel() {

    val messages: StateFlow<List<ChatMessageEntity>> = repository.getMessages()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val modelStatus: StateFlow<ModelStatus> = llmEngine.modelStatus
    val isGenerating: StateFlow<Boolean> = llmEngine.isGenerating
    val voiceState: StateFlow<VoiceInputState> = voiceInputManager.state
    val isSpeaking: StateFlow<Boolean> = voiceOutputManager.isSpeaking

    private val _streamingText = MutableStateFlow<String?>(null)
    val streamingText: StateFlow<String?> = _streamingText.asStateFlow()

    private val _pendingConfirmation = MutableStateFlow<PendingConfirmation?>(null)
    val pendingConfirmation: StateFlow<PendingConfirmation?> = _pendingConfirmation.asStateFlow()

    private val _isHybridOnline = MutableStateFlow(false)
    val isHybridOnline: StateFlow<Boolean> = _isHybridOnline.asStateFlow()

    private val _uiEvents = MutableSharedFlow<ChatUiEvent>()
    val uiEvents = _uiEvents.asSharedFlow()

    private var generationJob: Job? = null

    fun toggleHybridMode() {
        _isHybridOnline.value = !_isHybridOnline.value
        val label = if (_isHybridOnline.value) "Hybrid Mode (Online Tools Allowed)" else "Strict Offline Mode"
        viewModelScope.launch {
            _uiEvents.emit(ChatUiEvent.ShowToast(label))
        }
    }

    fun sendMessage(text: String, context: Context? = null) {
        if (text.isBlank()) return
        val trimmed = text.trim()

        viewModelScope.launch {
            // Save user message to local Room database
            repository.saveMessage(MessageSender.USER, trimmed)

            // Start streaming inference from local llama engine
            generationJob?.cancel()
            _streamingText.value = ""

            generationJob = viewModelScope.launch {
                val fullResponse = StringBuilder()

                llmEngine.streamResponse(trimmed).collect { token ->
                    fullResponse.append(token)
                    _streamingText.value = fullResponse.toString()
                }

                val finalOutput = fullResponse.toString().trim()
                _streamingText.value = null

                if (finalOutput.isNotEmpty()) {
                    // Check if LLM invoked any device tools
                    val toolResult = toolRegistry.executeToolsInText(finalOutput)

                    val messageToSave = if (toolResult != null) {
                        val cleanedText = finalOutput.replace(Regex("\\[TOOL:[^\\]]+\\]"), "").trim()
                        if (cleanedText.isNotEmpty()) {
                            "$cleanedText\n\n${toolResult.userSummary}"
                        } else {
                            toolResult.userSummary
                        }
                    } else {
                        finalOutput
                    }

                    // Save assistant message to local Room database
                    repository.saveMessage(MessageSender.ASSISTANT, messageToSave)

                    // If tool requires sensitive user confirmation (e.g. sending a message)
                    if (toolResult?.pendingConfirmation != null) {
                        _pendingConfirmation.value = toolResult.pendingConfirmation
                    }

                    // Auto-speak if enabled
                    // voiceOutputManager.speak(messageToSave)
                }
            }
        }
    }

    fun stopGeneration() {
        llmEngine.stopGeneration()
        generationJob?.cancel()
        generationJob = null
        val current = _streamingText.value
        _streamingText.value = null
        if (!current.isNullOrBlank()) {
            viewModelScope.launch {
                repository.saveMessage(MessageSender.ASSISTANT, "$current [Generation Stopped]")
            }
        }
    }

    fun startVoiceInput(context: Context) {
        voiceOutputManager.stop()
        voiceInputManager.startListening { recognizedText ->
            if (recognizedText.isNotBlank()) {
                sendMessage(recognizedText, context)
            }
        }
    }

    fun stopVoiceInput() {
        voiceInputManager.stopListening()
    }

    fun speakMessage(text: String) {
        if (voiceOutputManager.isSpeaking.value) {
            voiceOutputManager.stop()
        } else {
            voiceOutputManager.speak(text)
        }
    }

    fun confirmPendingAction(context: Context) {
        val pending = _pendingConfirmation.value ?: return
        try {
            context.startActivity(pending.actionIntent)
            viewModelScope.launch {
                _uiEvents.emit(ChatUiEvent.ShowToast("Dispatched action to ${pending.appChannel.uppercase()}"))
            }
        } catch (e: Exception) {
            viewModelScope.launch {
                _uiEvents.emit(ChatUiEvent.ShowToast("Failed to launch ${pending.appChannel}: ${e.localizedMessage}"))
            }
        } finally {
            _pendingConfirmation.value = null
        }
    }

    fun dismissPendingAction() {
        _pendingConfirmation.value = null
    }

    fun clearChat() {
        viewModelScope.launch {
            repository.clearHistory()
            _uiEvents.emit(ChatUiEvent.ShowToast("Chat history cleared from device"))
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceOutputManager.stop()
        voiceInputManager.stopListening()
    }
}
