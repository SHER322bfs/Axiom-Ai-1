package com.axiomai.app.domain.voice

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

sealed class VoiceInputState {
    object Idle : VoiceInputState()
    data class Listening(val rmsDb: Float) : VoiceInputState()
    object Processing : VoiceInputState()
    data class Success(val recognizedText: String) : VoiceInputState()
    data class Error(val message: String) : VoiceInputState()
}

enum class SpeechLanguage(val code: String, val displayName: String) {
    AUTO("auto", "Auto (English + Hindi / Hinglish)"),
    ENGLISH_INDIA("en-IN", "English (India)"),
    HINDI("hi-IN", "Hindi (हिन्दी)"),
    ENGLISH_US("en-US", "English (US)")
}

class VoiceInputManager(private val context: Context) {

    private val TAG = "VoiceInputManager"
    private var speechRecognizer: SpeechRecognizer? = null

    private val _state = MutableStateFlow<VoiceInputState>(VoiceInputState.Idle)
    val state: StateFlow<VoiceInputState> = _state.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _rmsLevel = MutableStateFlow(0f)
    val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

    private val _isOfflineSupported = MutableStateFlow(false)
    val isOfflineSupported: StateFlow<Boolean> = _isOfflineSupported.asStateFlow()

    val isOfflineAvailable: Boolean
        get() = _isOfflineSupported.value

    var selectedLanguage: SpeechLanguage = SpeechLanguage.AUTO

    init {
        checkOfflineSupport()
    }

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    /**
     * Honest check whether Android device has genuine offline speech model installed.
     * Uses SpeechRecognizer.isOnDeviceRecognitionAvailable on Android 12 (API 31+).
     */
    private fun checkOfflineSupport() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                _isOfflineSupported.value = SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
            } catch (e: Exception) {
                _isOfflineSupported.value = false
            }
        } else {
            // Android 11 and earlier cannot guarantee offline on-device speech recognition without network
            _isOfflineSupported.value = false
        }
    }

    fun startListening(
        onResult: (String) -> Unit,
        onError: (String) -> Unit = {}
    ) {
        startListeningInternal(preferOfflineOnly = _isOfflineSupported.value, onResult = onResult, onError = onError)
    }

    fun startListening(preferOfflineOnly: Boolean, onResult: (String) -> Unit) {
        startListeningInternal(preferOfflineOnly = preferOfflineOnly, onResult = onResult, onError = {})
    }

    private fun startListeningInternal(
        preferOfflineOnly: Boolean = false,
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        if (!isAvailable()) {
            val err = "Speech recognition service is not available on this Android device."
            _state.value = VoiceInputState.Error(err)
            _isListening.value = false
            onError(err)
            return
        }

        stopListening()

        // On Android 12+, use createOnDeviceSpeechRecognizer if available and requested
        speechRecognizer = if (preferOfflineOnly && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && _isOfflineSupported.value) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
        } else {
            SpeechRecognizer.createSpeechRecognizer(context)
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _state.value = VoiceInputState.Listening(0f)
                _isListening.value = true
                _rmsLevel.value = 0f
            }

            override fun onBeginningOfSpeech() {
                _state.value = VoiceInputState.Listening(2f)
                _isListening.value = true
            }

            override fun onRmsChanged(rmsdB: Float) {
                val clamped = rmsdB.coerceIn(0f, 10f)
                _rmsLevel.value = clamped
                if (_state.value is VoiceInputState.Listening) {
                    _state.value = VoiceInputState.Listening(clamped)
                }
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                _state.value = VoiceInputState.Processing
                _isListening.value = false
            }

            override fun onError(error: Int) {
                _isListening.value = false
                val message = when (error) {
                    SpeechRecognizer.ERROR_AUDIO -> "Audio recording error. Check your microphone."
                    SpeechRecognizer.ERROR_CLIENT -> "Client error in speech engine."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required."
                    SpeechRecognizer.ERROR_NETWORK -> "Network connection required for online speech recognition (offline speech model not installed on device)."
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout while contacting speech service."
                    SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized. Please speak clearly into the microphone."
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognition service is busy. Please wait a moment."
                    SpeechRecognizer.ERROR_SERVER -> "Recognition server error."
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech input detected."
                    else -> "Speech recognition error ($error)"
                }
                Log.w(TAG, "SpeechRecognizer error: $message")
                _state.value = VoiceInputState.Error(message)
                onError(message)
            }

            override fun onResults(results: Bundle?) {
                _isListening.value = false
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()?.trim() ?: ""
                if (text.isNotEmpty()) {
                    _state.value = VoiceInputState.Success(text)
                    onResult(text)
                } else {
                    val err = "Could not recognize speech."
                    _state.value = VoiceInputState.Error(err)
                    onError(err)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)

            if (preferOfflineOnly) {
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }

            when (selectedLanguage) {
                SpeechLanguage.AUTO -> {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                    putExtra(RecognizerIntent.EXTRA_ADDITIONAL_LANGUAGES, arrayOf("hi-IN", "en-US"))
                }
                SpeechLanguage.ENGLISH_INDIA -> {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                }
                SpeechLanguage.HINDI -> {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                }
                SpeechLanguage.ENGLISH_US -> {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                }
            }
        }

        try {
            speechRecognizer?.startListening(intent)
            _isListening.value = true
        } catch (e: Exception) {
            _isListening.value = false
            Log.e(TAG, "Error starting speech recognizer", e)
            val msg = e.localizedMessage ?: "Failed to start speech recognizer"
            _state.value = VoiceInputState.Error(msg)
            onError(msg)
        }
    }

    fun stopListening() {
        _isListening.value = false
        _rmsLevel.value = 0f
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (e: Exception) {
            Log.w(TAG, "Error destroying speech recognizer", e)
        }
        if (_state.value !is VoiceInputState.Success) {
            _state.value = VoiceInputState.Idle
        }
    }

    fun cancel() {
        stopListening()
    }
}
