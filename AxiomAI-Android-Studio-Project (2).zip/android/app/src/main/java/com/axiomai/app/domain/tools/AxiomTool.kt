package com.axiomai.app.domain.tools

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
import android.util.Log
import com.axiomai.app.service.AxiomNotificationListener

data class PendingConfirmation(
    val title: String,
    val recipient: String,
    val appChannel: String,
    val messageText: String,
    val actionIntent: Intent
)

data class ToolResult(
    val success: Boolean,
    val userSummary: String,
    val pendingConfirmation: PendingConfirmation? = null
)

interface AxiomTool {
    val id: String
    val name: String
    val description: String
    val requiresConfirmation: Boolean

    suspend fun execute(context: Context, params: Map<String, String>): ToolResult
}

class AppLauncherTool : AxiomTool {
    override val id = "app_launcher"
    override val name = "App Launcher"
    override val description = "Launches installed Android applications"
    override val requiresConfirmation = false

    override suspend fun execute(context: Context, params: Map<String, String>): ToolResult {
        val appName = params["app_name"]?.lowercase()?.trim() ?: ""
        val pm = context.packageManager

        val packageMap = mapOf(
            "chrome" to "com.android.chrome",
            "google chrome" to "com.android.chrome",
            "youtube" to "com.google.android.youtube",
            "whatsapp" to "com.whatsapp",
            "telegram" to "org.telegram.messenger",
            "gmail" to "com.google.android.gm",
            "maps" to "com.google.android.apps.maps",
            "camera" to "com.android.camera",
            "clock" to "com.google.android.deskclock",
            "calculator" to "com.google.android.calculator"
        )

        var targetPackage = packageMap[appName]

        if (targetPackage == null) {
            // Search installed applications
            val installed = pm.getInstalledApplications(0)
            val match = installed.firstOrNull { app ->
                val label = pm.getApplicationLabel(app).toString().lowercase()
                label.contains(appName) || appName.contains(label)
            }
            targetPackage = match?.packageName
        }

        if (targetPackage == null) {
            return ToolResult(false, "Could not find an installed app matching \"$appName\" on this device.")
        }

        val launchIntent = pm.getLaunchIntentForPackage(targetPackage)
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            ToolResult(true, "Opened $appName successfully.")
        } else {
            ToolResult(false, "App \"$appName\" is installed but could not be launched directly.")
        }
    }
}

class SettingsPageTool : AxiomTool {
    override val id = "settings_page"
    override val name = "Settings Controller"
    override val description = "Opens device settings pages (Wi-Fi, Bluetooth, Battery, etc.)"
    override val requiresConfirmation = false

    override suspend fun execute(context: Context, params: Map<String, String>): ToolResult {
        val page = params["page"]?.lowercase()?.trim() ?: "main"

        val action = when (page) {
            "wifi", "wi-fi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "battery" -> Settings.ACTION_POWER_USAGE_SUMMARY
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }

        return try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ToolResult(true, "Opened $page settings.")
        } catch (e: Exception) {
            ToolResult(false, "Could not open $page settings: ${e.localizedMessage}")
        }
    }
}

class AlarmReminderTool : AxiomTool {
    override val id = "set_alarm"
    override val name = "Alarm & Reminder"
    override val description = "Sets alarms via standard Android Clock API"
    override val requiresConfirmation = false

    override suspend fun execute(context: Context, params: Map<String, String>): ToolResult {
        val hour = params["hour"]?.toIntOrNull() ?: 7
        val minute = params["minute"]?.toIntOrNull() ?: 0
        val message = params["message"] ?: "Axiom AI Alarm"

        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, message)
            putExtra(AlarmClock.EXTRA_SKIP_UI, false) // Show Clock UI so user sees confirmation
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            context.startActivity(intent)
            ToolResult(true, "Alarm set for %02d:%02d with label \"$message\".".format(hour, minute))
        } catch (e: Exception) {
            ToolResult(false, "Could not set alarm: ${e.localizedMessage}")
        }
    }
}

class DialerTool : AxiomTool {
    override val id = "dial_phone"
    override val name = "Phone Dialer"
    override val description = "Prepares phone dialer with phone number"
    override val requiresConfirmation = false

    override suspend fun execute(context: Context, params: Map<String, String>): ToolResult {
        val number = params["number"]?.trim() ?: ""
        if (number.isEmpty()) {
            return ToolResult(false, "No phone number provided to dial.")
        }

        val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            context.startActivity(dialIntent)
            ToolResult(true, "Opened phone dialer with number $number. Tap the green call button to connect.")
        } catch (e: Exception) {
            ToolResult(false, "Could not open phone dialer: ${e.localizedMessage}")
        }
    }
}

class WebSearchTool : AxiomTool {
    override val id = "search_web"
    override val name = "Web Search"
    override val description = "Searches the web in default browser"
    override val requiresConfirmation = false

    override suspend fun execute(context: Context, params: Map<String, String>): ToolResult {
        val query = params["query"]?.trim() ?: ""
        if (query.isEmpty()) {
            return ToolResult(false, "Search query is empty.")
        }

        val searchIntent = Intent(Intent.ACTION_WEB_SEARCH).apply {
            putExtra("query", query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            context.startActivity(searchIntent)
            ToolResult(true, "Searching the web for \"$query\".")
        } catch (e: Exception) {
            // Fallback to URL browser intent
            try {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(browserIntent)
                ToolResult(true, "Opened search for \"$query\" in browser.")
            } catch (ex: Exception) {
                ToolResult(false, "Could not launch search: ${ex.localizedMessage}")
            }
        }
    }
}

/**
 * High-Safety Communication Tool:
 * Enforces explicit user confirmation before opening WhatsApp, Telegram, or sending SMS.
 */
class CommunicationTool : AxiomTool {
    override val id = "prepare_message"
    override val name = "Communication Messenger"
    override val description = "Prepares messages for WhatsApp, Telegram, or SMS with explicit user confirmation"
    override val requiresConfirmation = true

    override suspend fun execute(context: Context, params: Map<String, String>): ToolResult {
        val contact = params["contact"] ?: "Recipient"
        val app = params["app"]?.lowercase() ?: "whatsapp"
        val text = params["text"] ?: ""

        val actionIntent: Intent = when (app) {
            "whatsapp" -> {
                Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse("https://api.whatsapp.com/send?text=" + Uri.encode(text))
                    setPackage("com.whatsapp")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
            "telegram" -> {
                Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse("tg://msg?text=" + Uri.encode(text))
                    setPackage("org.telegram.messenger")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
            else -> {
                // Default SMS
                Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("smsto:")
                    putExtra("sms_body", text)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
        }

        val pending = PendingConfirmation(
            title = "Send Message via ${app.replaceFirstChar { it.uppercase() }}",
            recipient = contact,
            appChannel = app,
            messageText = text,
            actionIntent = actionIntent
        )

        return ToolResult(
            success = true,
            userSummary = "Message prepared for $contact via ${app.uppercase()}. Please confirm in the dialog to send.",
            pendingConfirmation = pending
        )
    }
}

class NotificationReaderTool : AxiomTool {
    override val id = "read_notifications"
    override val name = "Notification Reader"
    override val description = "Reads recently received authorized notifications"
    override val requiresConfirmation = false

    override suspend fun execute(context: Context, params: Map<String, String>): ToolResult {
        val list = AxiomNotificationListener.getRecentNotifications()
        if (list.isEmpty()) {
            return ToolResult(true, "No recent notifications received. Make sure Axiom Notification Access is enabled in Settings > Permissions.")
        }

        val summary = StringBuilder("Here are your recent notifications:\n")
        list.take(4).forEachIndexed { index, notif ->
            summary.append("${index + 1}. **${notif.appTitle}** (${notif.title}): ${notif.text}\n")
        }
        return ToolResult(true, summary.toString().trim())
    }
}
