package com.axiomai.app.domain.voice

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed class WakeWordState {
    object Idle : WakeWordState()
    object Listening : WakeWordState()
    data class Unavailable(val reason: String) : WakeWordState()
}

/**
 * WakeWordManager:
 * Honestly reports that continuous background wake-word listening without an active
 * acoustic DSP model (e.g., Picovoice Porcupine or openWakeWord) is unavailable on Android 12+
 * due to OS battery, privacy, and background microphone restrictions.
 * Push-to-Talk via the microphone button is the supported, battery-friendly method.
 */
class WakeWordManager(private val context: Context) {

    private val _state = MutableStateFlow<WakeWordState>(
        WakeWordState.Unavailable(
            "Continuous background wake-word listening is unavailable: Android 12+ restricts background microphone capture without a trained DSP acoustic engine. Please use Push-to-Talk in Voice Mode."
        )
    )
    val state: StateFlow<WakeWordState> = _state.asStateFlow()

    private val _isSupported = MutableStateFlow(false)
    val isSupported: StateFlow<Boolean> = _isSupported.asStateFlow()

    val wakeWord: StateFlow<String> = MutableStateFlow("Push-to-Talk only")

    fun startListening(scope: CoroutineScope, onTriggered: () -> Unit) {
        // Honest handling: Continuous wake-word is marked unavailable.
        // We do NOT simulate fake wake-word detections.
        _state.value = WakeWordState.Unavailable(
            "Continuous background wake-word is disabled. Push-to-Talk is available in Voice Mode."
        )
    }

    fun stopListening() {
        _state.value = WakeWordState.Idle
    }

    fun getLimitationExplanation(): String {
        return "Continuous background wake-word detection is disabled. Android 12+ strictly limits continuous background microphone capture to preserve battery and privacy unless a specialized acoustic model is running on dedicated DSP hardware. Use Push-to-Talk via the floating Orb or mic button."
    }
}
