package com.axiomai.app.presentation.voice

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.axiomai.app.domain.engine.LocalLlmEngine
import com.axiomai.app.domain.voice.VoiceInputManager
import com.axiomai.app.domain.voice.VoiceOutputManager
import com.axiomai.app.presentation.components.AnimatedAiOrb
import com.axiomai.app.presentation.components.OrbState
import kotlinx.coroutines.launch

@Composable
fun VoiceModeScreen(
    llmEngine: LocalLlmEngine,
    voiceInputManager: VoiceInputManager,
    voiceOutputManager: VoiceOutputManager,
    onNavigateBack: () -> Unit,
    onNavigateToChat: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val isListening by voiceInputManager.isListening.collectAsState()
    val rmsLevel by voiceInputManager.rmsLevel.collectAsState()
    val isSpeaking by voiceOutputManager.isSpeaking.collectAsState()
    val modelState by llmEngine.modelState.collectAsState()

    var userTranscript by remember { mutableStateOf("") }
    var assistantReply by remember { mutableStateOf("") }
    var voiceMuted by remember { mutableStateOf(false) }

    // Derive current Orb state
    val orbState = when {
        isListening -> OrbState.Listening(rmsDb = rmsLevel)
        modelState.isGenerating -> OrbState.Thinking
        isSpeaking -> OrbState.Speaking(audioLevel = 0.75f)
        else -> OrbState.Idle
    }

    DisposableEffect(Unit) {
        onDispose {
            voiceInputManager.cancel()
            voiceOutputManager.stop()
        }
    }

    val bgGradient = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF0F111D),
            Color(0xFF090A0F),
            Color(0xFF050508)
        )
    )

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF050508)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(bgGradient)
                .padding(24.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Header Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E2235).copy(alpha = 0.6f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }

                    // Recognition Mode Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFF1E2235))
                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(20.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = if (voiceInputManager.isOfflineAvailable) "● Offline Speech Engine" else "● Standard Speech Engine",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (voiceInputManager.isOfflineAvailable) Color(0xFF10B981) else Color(0xFF38BDF8)
                        )
                    }

                    IconButton(
                        onClick = {
                            voiceMuted = !voiceMuted
                            if (voiceMuted) voiceOutputManager.stop()
                        },
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E2235).copy(alpha = 0.6f))
                    ) {
                        Icon(
                            imageVector = if (voiceMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                            contentDescription = "Toggle Mute",
                            tint = if (voiceMuted) Color(0xFFEF4444) else Color(0xFFA78BFA)
                        )
                    }
                }

                // Center AI Orb & Live Subtitles
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    AnimatedAiOrb(
                        state = orbState,
                        size = 240.dp,
                        onClick = {
                            if (isListening) {
                                voiceInputManager.stopListening()
                            } else if (isSpeaking || modelState.isGenerating) {
                                llmEngine.stopGeneration()
                                voiceOutputManager.stop()
                            } else {
                                userTranscript = ""
                                assistantReply = ""
                                voiceInputManager.startListening(
                                    onResult = { query ->
                                        userTranscript = query
                                        // Execute inference
                                        scope.launch {
                                            assistantReply = ""
                                            llmEngine.generateResponse(query).collect { token ->
                                                assistantReply += token
                                            }
                                            if (!voiceMuted && assistantReply.isNotBlank()) {
                                                voiceOutputManager.speak(assistantReply)
                                            }
                                        }
                                    },
                                    onError = { err ->
                                        userTranscript = "Voice error: $err"
                                    }
                                )
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(28.dp))

                    // Status Indicator
                    Text(
                        text = when {
                            isListening -> "Listening to your voice..."
                            modelState.isGenerating -> "Thinking locally on Dimensity 1300..."
                            isSpeaking -> "Speaking response..."
                            else -> "Tap Orb or Button to Talk"
                        },
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = when {
                            isListening -> Color(0xFF38BDF8)
                            modelState.isGenerating -> Color(0xFFF472B6)
                            isSpeaking -> Color(0xFF34D399)
                            else -> Color(0xFF94A3B8)
                        }
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Live Subtitle Card
                    if (userTranscript.isNotBlank() || assistantReply.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0xFF131520).copy(alpha = 0.85f))
                                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp))
                                .padding(16.dp)
                        ) {
                            Column {
                                if (userTranscript.isNotBlank()) {
                                    Text(
                                        text = "You: $userTranscript",
                                        fontSize = 13.sp,
                                        color = Color(0xFFE2E8F0),
                                        fontWeight = FontWeight.Medium
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                }
                                if (assistantReply.isNotBlank()) {
                                    Text(
                                        text = "Axiom: $assistantReply",
                                        fontSize = 13.sp,
                                        color = Color(0xFFA78BFA),
                                        lineHeight = 18.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // Bottom Action Bar
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Switch to Text Chat
                        IconButton(
                            onClick = onNavigateToChat,
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF1E2235))
                        ) {
                            Icon(
                                imageVector = Icons.Default.ChatBubble,
                                contentDescription = "Chat",
                                tint = Color.White
                            )
                        }

                        // Main Push-To-Talk Button
                        Box(
                            modifier = Modifier
                                .size(76.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isListening) Color(0xFFEF4444) else Color(0xFF7C3AED)
                                )
                                .clickable {
                                    if (isListening) {
                                        voiceInputManager.stopListening()
                                    } else {
                                        userTranscript = ""
                                        assistantReply = ""
                                        voiceInputManager.startListening(
                                            onResult = { query ->
                                                userTranscript = query
                                                scope.launch {
                                                    assistantReply = ""
                                                    llmEngine.generateResponse(query).collect { token ->
                                                        assistantReply += token
                                                    }
                                                    if (!voiceMuted && assistantReply.isNotBlank()) {
                                                        voiceOutputManager.speak(assistantReply)
                                                    }
                                                }
                                            },
                                            onError = { err ->
                                                userTranscript = "Voice error: $err"
                                            }
                                        )
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                                contentDescription = "Voice Action",
                                tint = Color.White,
                                modifier = Modifier.size(34.dp)
                            )
                        }

                        // Stop/Interrupt Button
                        IconButton(
                            onClick = {
                                voiceInputManager.cancel()
                                llmEngine.stopGeneration()
                                voiceOutputManager.stop()
                            },
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF1E2235))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Interrupt",
                                tint = Color(0xFF94A3B8)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Press and speak clearly • Natural Hindi, English, or Hinglish",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
