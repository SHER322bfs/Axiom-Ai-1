package com.axiomai.app.presentation.automation

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.axiomai.app.domain.tools.SafeMessengerTool
import com.axiomai.app.domain.tools.ToolRegistry
import kotlinx.coroutines.launch

data class AutomationItem(
    val id: String,
    val name: String,
    val description: String,
    val icon: ImageVector,
    val sampleCommand: String,
    val category: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AutomationScreen(
    toolRegistry: ToolRegistry,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var testResultDialog by remember { mutableStateOf<String?>(null) }
    var pendingSafeMessage by remember { mutableStateOf<Pair<String, String>?>(null) } // Target, Message

    val automations = remember {
        listOf(
            AutomationItem(
                id = "alarm",
                name = "Alarm & Timer Scheduler",
                description = "Sets system alarms and timers hands-free using AlarmClock provider",
                icon = Icons.Default.Alarm,
                sampleCommand = "Set an alarm for 6:30 AM",
                category = "System"
            ),
            AutomationItem(
                id = "app_launcher",
                name = "App Quick Launcher",
                description = "Opens installed apps like WhatsApp, Telegram, YouTube, Chrome, Camera",
                icon = Icons.Default.Apps,
                sampleCommand = "Open YouTube",
                category = "Application"
            ),
            AutomationItem(
                id = "dialer",
                name = "Phone Dialer",
                description = "Prepares phone calls and opens system dialer safely without auto-calling",
                icon = Icons.Default.Call,
                sampleCommand = "Call Mom",
                category = "Communication"
            ),
            AutomationItem(
                id = "safe_messenger",
                name = "Safe Messenger (Confirmation Required)",
                description = "Drafts WhatsApp/Telegram/SMS message with mandatory confirmation popup",
                icon = Icons.Default.Send,
                sampleCommand = "Draft WhatsApp to Rahul: I will arrive in 10 minutes",
                category = "Security"
            ),
            AutomationItem(
                id = "notifications",
                name = "Notification Summarizer",
                description = "Reads unread device notifications via authorized ListenerService",
                icon = Icons.Default.Notifications,
                sampleCommand = "Summarize latest notifications",
                category = "Intelligence"
            ),
            AutomationItem(
                id = "search",
                name = "Online Search Fallback",
                description = "Performs external web query when device is connected to the internet",
                icon = Icons.Default.Search,
                sampleCommand = "Search for latest space discoveries",
                category = "Web"
            )
        )
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF090A0F)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Automations & Tools",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Deterministic Device Integrations",
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0D0E15)
                )
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    // Safety Banner
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF131520)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF7C3AED).copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = null,
                                tint = Color(0xFFA78BFA),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "Axiom AI strictly enforces confirmation dialogs before sending any messages or placing phone calls.",
                                fontSize = 12.sp,
                                color = Color(0xFFCBD5E1)
                            )
                        }
                    }
                }

                items(automations) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF131520)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(Color(0xFF1E2235)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = item.icon,
                                            contentDescription = null,
                                            tint = Color(0xFFA78BFA),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = item.name,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color.White
                                        )
                                        Text(
                                            text = item.category,
                                            fontSize = 10.sp,
                                            color = Color(0xFF64748B)
                                        )
                                    }
                                }

                                Button(
                                    onClick = {
                                        scope.launch {
                                            when (item.id) {
                                                "alarm" -> {
                                                    val res = toolRegistry.executeTool("set_alarm", mapOf("hour" to "7", "minute" to "00"))
                                                    testResultDialog = res.output
                                                }
                                                "app_launcher" -> {
                                                    val res = toolRegistry.executeTool("open_app", mapOf("app_name" to "YouTube"))
                                                    testResultDialog = res.output
                                                }
                                                "dialer" -> {
                                                    val res = toolRegistry.executeTool("dial_phone", mapOf("phone_number" to "+919876543210"))
                                                    testResultDialog = res.output
                                                }
                                                "safe_messenger" -> {
                                                    pendingSafeMessage = Pair("WhatsApp (+91 98765 43210)", "Meeting scheduled for 4 PM today.")
                                                }
                                                "notifications" -> {
                                                    val res = toolRegistry.executeTool("summarize_notifications", emptyMap())
                                                    testResultDialog = res.output
                                                }
                                                "search" -> {
                                                    val res = toolRegistry.executeTool("web_search", mapOf("query" to "Offline LLMs on ARM64"))
                                                    testResultDialog = res.output
                                                }
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2235)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "Test Tool",
                                        fontSize = 11.sp,
                                        color = Color(0xFFA78BFA)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = item.description,
                                fontSize = 12.sp,
                                color = Color(0xFF94A3B8)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF0A0B10))
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "Command: \"${item.sampleCommand}\"",
                                    fontSize = 11.sp,
                                    color = Color(0xFF38BDF8)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Test Result Alert Dialog
        testResultDialog?.let { result ->
            AlertDialog(
                onDismissRequest = { testResultDialog = null },
                title = { Text(text = "Automation Result", color = Color.White) },
                text = { Text(text = result, color = Color(0xFFCBD5E1)) },
                confirmButton = {
                    TextButton(onClick = { testResultDialog = null }) {
                        Text(text = "OK", color = Color(0xFFA78BFA))
                    }
                },
                containerColor = Color(0xFF131520)
            )
        }

        // Safe Messenger Mandatory Confirmation Dialog
        pendingSafeMessage?.let { (target, msg) ->
            AlertDialog(
                onDismissRequest = { pendingSafeMessage = null },
                title = { Text(text = "Confirm Send Message", color = Color.White) },
                text = {
                    Column {
                        Text(
                            text = "Axiom AI requires your explicit confirmation before dispatching:",
                            fontSize = 13.sp,
                            color = Color(0xFF94A3B8)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(text = "Target: $target", fontWeight = FontWeight.Bold, color = Color.White)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Message: \"$msg\"", color = Color(0xFFA78BFA))
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            scope.launch {
                                val res = toolRegistry.executeTool(
                                    "send_message",
                                    mapOf("target" to target, "message" to msg)
                                )
                                pendingSafeMessage = null
                                testResultDialog = res.output
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED))
                    ) {
                        Text(text = "Confirm & Send")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { pendingSafeMessage = null }) {
                        Text(text = "Cancel", color = Color(0xFFEF4444))
                    }
                },
                containerColor = Color(0xFF131520)
            )
        }
    }
}
