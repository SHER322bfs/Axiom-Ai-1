package com.axiomai.app.domain.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class VoiceOutputManager(context: Context) : TextToSpeech.OnInitListener {

    private val TAG = "VoiceOutputManager"
    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _speechRate = MutableStateFlow(1.0f)
    val speechRate: StateFlow<Float> = _speechRate.asStateFlow()

    private val hindiLocale = Locale("hi", "IN")
    private val englishIndiaLocale = Locale("en", "IN")

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    _isSpeaking.value = false
                }
            })

            // Set default speech rate
            tts?.setSpeechRate(_speechRate.value)
            Log.i(TAG, "TTS initialized successfully")
        } else {
            Log.e(TAG, "TTS initialization failed with status: $status")
            isInitialized = false
        }
    }

    fun setSpeechRate(rate: Float) {
        val clamped = rate.coerceIn(0.5f, 2.0f)
        _speechRate.value = clamped
        tts?.setSpeechRate(clamped)
    }

    /**
     * Strips markdown and internal tool markup before feeding to the audio synthesizer.
     */
    private fun cleanTextForSpeech(text: String): String {
        return text
            .replace(Regex("\\[TOOL:[^\\]]+\\]"), "") // Remove tool invocations
            .replace(Regex("\\*\\*([^*]+)\\*\\*"), "$1") // Bold
            .replace(Regex("\\*([^*]+)\\*"), "$1") // Italics
            .replace(Regex("`[^`]+`"), "") // Code
            .replace(Regex("#+\\s*"), "") // Headers
            .replace(Regex("•\\s*"), "") // Bullet points
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun speak(text: String) {
        if (!isInitialized || tts == null) return

        val clean = cleanTextForSpeech(text)
        if (clean.isBlank()) return

        // Auto-detect Hindi vs English
        val containsHindi = clean.any { it in '\u0900'..'\u097F' }
        val targetLocale = if (containsHindi) {
            val res = tts?.isLanguageAvailable(hindiLocale)
            if (res == TextToSpeech.LANG_AVAILABLE || res == TextToSpeech.LANG_COUNTRY_AVAILABLE) {
                hindiLocale
            } else {
                englishIndiaLocale
            }
        } else {
            englishIndiaLocale
        }

        tts?.language = targetLocale
        tts?.setSpeechRate(_speechRate.value)

        val utteranceId = "axiom_${System.currentTimeMillis()}"
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
        tts = null
    }
}
