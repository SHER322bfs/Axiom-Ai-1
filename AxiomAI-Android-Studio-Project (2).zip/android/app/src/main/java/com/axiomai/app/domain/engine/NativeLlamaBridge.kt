package com.axiomai.app.domain.engine

import android.util.Log

interface NativeTokenCallback {
    fun onTokenGenerated(token: String)
}

/**
 * JNI Bridge to native C++ llama.cpp engine.
 */
object NativeLlamaBridge {
    private const val TAG = "NativeLlamaBridge"
    private var isLibraryLoaded = false

    init {
        try {
            System.loadLibrary("axiom_llama")
            isLibraryLoaded = true
            Log.i(TAG, "Native library libaxiom_llama.so successfully loaded.")
        } catch (e: UnsatisfiedLinkError) {
            Log.w(TAG, "Native library libaxiom_llama.so not loaded: ${e.message}.")
            isLibraryLoaded = false
        }
    }

    fun isNativeLoaded(): Boolean = isLibraryLoaded

    external fun nativeValidateGguf(path: String): String
    external fun nativeLoadModel(path: String, nThreads: Int, contextSize: Int, useGpu: Boolean): Boolean
    external fun nativeUnloadModel()
    external fun nativeStopGeneration()
    external fun nativeIsModelLoaded(): Boolean
    external fun nativeGenerateTokens(prompt: String, callback: NativeTokenCallback): Boolean
}
