package com.axiomai.app.presentation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.axiomai.app.AxiomApplication
import com.axiomai.app.presentation.automation.AutomationScreen
import com.axiomai.app.presentation.chat.ChatScreen
import com.axiomai.app.presentation.chat.ChatViewModel
import com.axiomai.app.presentation.history.HistoryScreen
import com.axiomai.app.presentation.home.HomeScreen
import com.axiomai.app.presentation.modelmanager.ModelManagerScreen
import com.axiomai.app.presentation.modelmanager.ModelManagerViewModel
import com.axiomai.app.presentation.privacy.PrivacyScreen
import com.axiomai.app.presentation.settings.SettingsScreen
import com.axiomai.app.presentation.settings.SettingsViewModel
import com.axiomai.app.presentation.voice.VoiceModeScreen

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Chat : Screen("chat")
    object VoiceMode : Screen("voice_mode")
    object ModelManager : Screen("model_manager")
    object Automation : Screen("automation")
    object History : Screen("history")
    object Settings : Screen("settings")
    object Privacy : Screen("privacy")
}

@Composable
fun AxiomNavGraph(
    navController: NavHostController,
    app: AxiomApplication
) {
    val chatViewModel = ChatViewModel(
        repository = app.chatRepository,
        llmEngine = app.llmEngine,
        voiceInputManager = app.voiceInputManager,
        voiceOutputManager = app.voiceOutputManager,
        toolRegistry = app.toolRegistry
    )

    val settingsViewModel = SettingsViewModel(
        repository = app.chatRepository,
        llmEngine = app.llmEngine,
        voiceInputManager = app.voiceInputManager,
        voiceOutputManager = app.voiceOutputManager,
        wakeWordManager = app.wakeWordManager
    )

    val modelManagerViewModel = ModelManagerViewModel(
        modelManager = app.modelManager,
        llmEngine = app.llmEngine
    )

    NavHost(
        navController = navController,
        startDestination = Screen.Home.route
    ) {
        // 1. Home Screen (Neural Hub)
        composable(Screen.Home.route) {
            HomeScreen(
                llmEngine = app.llmEngine,
                onNavigateToChat = { initialPrompt ->
                    if (!initialPrompt.isNullOrBlank()) {
                        chatViewModel.sendMessage(initialPrompt)
                    }
                    navController.navigate(Screen.Chat.route)
                },
                onNavigateToVoice = {
                    navController.navigate(Screen.VoiceMode.route)
                },
                onNavigateToModelManager = {
                    navController.navigate(Screen.ModelManager.route)
                },
                onNavigateToAutomation = {
                    navController.navigate(Screen.Automation.route)
                },
                onNavigateToHistory = {
                    navController.navigate(Screen.History.route)
                },
                onNavigateToSettings = {
                    navController.navigate(Screen.Settings.route)
                },
                onNavigateToPrivacy = {
                    navController.navigate(Screen.Privacy.route)
                }
            )
        }

        // 2. Chat Screen
        composable(Screen.Chat.route) {
            ChatScreen(
                viewModel = chatViewModel,
                onNavigateToSettings = {
                    navController.navigate(Screen.Settings.route)
                }
            )
        }

        // 3. Voice Mode (Dedicated Full Screen Animated Orb)
        composable(Screen.VoiceMode.route) {
            VoiceModeScreen(
                llmEngine = app.llmEngine,
                voiceInputManager = app.voiceInputManager,
                voiceOutputManager = app.voiceOutputManager,
                onNavigateBack = {
                    navController.popBackStack()
                },
                onNavigateToChat = {
                    navController.navigate(Screen.Chat.route) {
                        popUpTo(Screen.Home.route)
                    }
                }
            )
        }

        // 4. Model Manager
        composable(Screen.ModelManager.route) {
            ModelManagerScreen(
                viewModel = modelManagerViewModel,
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }

        // 5. Automation & Tools
        composable(Screen.Automation.route) {
            AutomationScreen(
                toolRegistry = app.toolRegistry,
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }

        // 6. Conversation History
        composable(Screen.History.route) {
            HistoryScreen(
                repository = app.chatRepository,
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }

        // 7. Settings
        composable(Screen.Settings.route) {
            SettingsScreen(
                viewModel = settingsViewModel,
                onNavigateBack = {
                    navController.popBackStack()
                },
                onNavigateToModelManager = {
                    navController.navigate(Screen.ModelManager.route)
                }
            )
        }

        // 8. Privacy & Permissions
        composable(Screen.Privacy.route) {
            PrivacyScreen(
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}
