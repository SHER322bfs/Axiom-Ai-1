package com.axiomai.app.presentation.settings

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.axiomai.app.domain.engine.ModelStatus
import com.axiomai.app.domain.voice.WakeWordState
import com.axiomai.app.theme.*
import kotlinx.coroutines.flow.collectLatest

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToModelManager: () -> Unit
) {
    val context = LocalContext.current
    val modelStatus by viewModel.modelStatus.collectAsState()
    val config by viewModel.engineConfig.collectAsState()
    val ttsRate by viewModel.ttsRate.collectAsState()
    val permissions by viewModel.permissions.collectAsState()
    val isOfflineSpeechSupported by viewModel.isOfflineSpeechSupported.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.checkPermissions(context)
        viewModel.uiEvents.collectLatest { event ->
            when (event) {
                is SettingsUiEvent.ShowToast -> {
                    Toast.makeText(context, event.message, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Settings",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimaryDark
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = VoidBlack)
            )
        },
        containerColor = VoidBlack
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Section 1: Model Manager Navigation Card
            Text(
                text = "Model Management",
                style = MaterialTheme.typography.titleMedium,
                color = PrimaryViolet,
                fontWeight = FontWeight.Bold
            )

            Surface(
                color = SurfaceDark,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, CardBorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Active Model", style = MaterialTheme.typography.bodyMedium, color = TextSecondaryDark)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = when (val s = modelStatus) {
                                    is ModelStatus.NoModelInstalled -> "No local model installed"
                                    is ModelStatus.ModelReady -> s.modelName
                                    is ModelStatus.Loading -> "Loading ${s.modelName}..."
                                    is ModelStatus.Error -> "Engine error: ${s.message}"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = when (modelStatus) {
                                    is ModelStatus.NoModelInstalled -> StatusWarning
                                    is ModelStatus.ModelReady -> StatusSuccess
                                    else -> TextPrimaryDark
                                }
                            )
                        }

                        Surface(
                            color = if (modelStatus is ModelStatus.NoModelInstalled) StatusWarningBg else StatusSuccessBg,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = if (modelStatus is ModelStatus.NoModelInstalled) "UNCONFIGURED" else "ONLINE",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (modelStatus is ModelStatus.NoModelInstalled) StatusWarning else StatusSuccess
                            )
                        }
                    }

                    Button(
                        onClick = onNavigateToModelManager,
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryViolet),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Open Model Manager (GGUF)", fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            // Section 2: Voice Input & Output Settings
            Text(
                text = "Voice & Speech Engine",
                style = MaterialTheme.typography.titleMedium,
                color = PrimaryViolet,
                fontWeight = FontWeight.Bold
            )

            Surface(
                color = SurfaceDark,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, CardBorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    // Speech Recognition status
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Speech Recognition", color = TextPrimaryDark, fontSize = 13.sp)
                            Text(
                                text = if (isOfflineSpeechSupported) "On-Device Offline Recognizer Ready" else "Google Online Speech Service",
                                color = if (isOfflineSpeechSupported) StatusSuccess else TextMutedDark,
                                fontSize = 11.sp
                            )
                        }
                        Surface(
                            color = if (isOfflineSpeechSupported) StatusSuccessBg else CardDark,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = if (isOfflineSpeechSupported) "OFFLINE" else "HYBRID",
                                fontSize = 10.sp,
                                color = if (isOfflineSpeechSupported) StatusSuccess else AccentPurpleLight,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = CardBorderDark)

                    // TTS Speed Slider
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Speaking Speed (TTS)", color = TextPrimaryDark, fontSize = 13.sp)
                            Text("${String.format("%.2f", ttsRate)}x", color = AccentPurpleLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Slider(
                            value = ttsRate,
                            onValueChange = { viewModel.setSpeechRate(it) },
                            valueRange = 0.5f..1.8f,
                            steps = 5,
                            colors = SliderDefaults.colors(
                                thumbColor = PrimaryViolet,
                                activeTrackColor = PrimaryViolet,
                                inactiveTrackColor = CardDark
                            )
                        )
                    }

                    OutlinedButton(
                        onClick = { viewModel.testSpeech() },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.VolumeUp, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Test Voice Synthesis")
                    }
                }
            }

            // Section 3: Wake Word System (Honest Unavailable / Push-to-Talk)
            Text(
                text = "Wake-Word System",
                style = MaterialTheme.typography.titleMedium,
                color = PrimaryViolet,
                fontWeight = FontWeight.Bold
            )

            Surface(
                color = SurfaceDark,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, CardBorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Acoustic Wake Word", color = TextPrimaryDark, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("Continuous voice detection", color = TextMutedDark, fontSize = 11.sp)
                        }
                        Surface(
                            color = StatusWarningBg,
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, StatusWarning.copy(alpha = 0.3f))
                        ) {
                            Text(
                                text = "NOT IMPLEMENTED",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = StatusWarning,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Text(
                        text = "Continuous on-device wake-word detection is unavailable because no licensed proprietary neural wake-word engine (such as Picovoice Porcupine or openWakeWord) is bundled, and Android 12+ restricts background audio capture. Please use the Push-to-Talk microphone button inside the chat interface.",
                        color = TextSecondaryDark,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }

            // Section 4: Engine Hardware Tuning (Dimensity 1300)
            Text(
                text = "Hardware Performance (Dimensity 1300)",
                style = MaterialTheme.typography.titleMedium,
                color = PrimaryViolet,
                fontWeight = FontWeight.Bold
            )

            Surface(
                color = SurfaceDark,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, CardBorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("CPU Inference Threads", color = TextPrimaryDark, fontSize = 13.sp)
                            Text("${config.nThreads} Cortex-A78 cores allocated", color = TextMutedDark, fontSize = 11.sp)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(2, 4, 6, 8).forEach { t ->
                                FilterChip(
                                    selected = config.nThreads == t,
                                    onClick = { viewModel.updateCpuThreads(t) },
                                    label = { Text("$t") }
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = CardBorderDark)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Context Buffer", color = TextPrimaryDark, fontSize = 13.sp)
                            Text("${config.contextSize} tokens", color = TextMutedDark, fontSize = 11.sp)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(1024, 2048, 4096).forEach { ctx ->
                                FilterChip(
                                    selected = config.contextSize == ctx,
                                    onClick = { viewModel.updateContextSize(ctx) },
                                    label = { Text(if (ctx >= 1024) "${ctx/1024}k" else "$ctx") }
                                )
                            }
                        }
                    }
                }
            }

            // Section 5: Permission Dashboard
            Text(
                text = "Permission Dashboard",
                style = MaterialTheme.typography.titleMedium,
                color = PrimaryViolet,
                fontWeight = FontWeight.Bold
            )

            Surface(
                color = SurfaceDark,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, CardBorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    PermissionRow(title = "Microphone (RECORD_AUDIO)", isGranted = permissions.hasAudioPermission)
                    PermissionRow(title = "Notifications (POST_NOTIFICATIONS)", isGranted = permissions.hasNotificationPermission)
                    PermissionRow(title = "Battery Unrestricted (Background)", isGranted = permissions.isBatteryOptimizedIgnored)

                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedButton(
                        onClick = {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.fromParts("package", context.packageName, null)
                            }
                            context.startActivity(intent)
                        },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Open App System Settings")
                    }
                }
            }

            // Section 6: Privacy & Storage
            Text(
                text = "Privacy & Local Data",
                style = MaterialTheme.typography.titleMedium,
                color = PrimaryViolet,
                fontWeight = FontWeight.Bold
            )

            Surface(
                color = SurfaceDark,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, CardBorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Axiom AI does not transmit conversation history or telemetry to cloud servers. All conversations remain in SQLite on your physical device.",
                        color = TextSecondaryDark,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                    Button(
                        onClick = { viewModel.clearChatHistory() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Delete All Local Chat History")
                    }
                }
            }
        }
    }
}
