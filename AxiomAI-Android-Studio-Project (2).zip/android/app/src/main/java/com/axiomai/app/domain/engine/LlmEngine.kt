package com.axiomai.app.domain.engine

import android.content.Context
import android.util.Log
import com.axiomai.app.domain.model.GgufModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

sealed class ModelStatus {
    object NoModelInstalled : ModelStatus() {
        const val label = "No local model installed"
    }
    data class Loading(val modelName: String, val progress: Float) : ModelStatus()
    data class ModelReady(val modelName: String, val filePath: String, val sizeMb: Long) : ModelStatus()
    data class Error(val message: String) : ModelStatus()
}

data class LlmEngineState(
    val isModelLoaded: Boolean = false,
    val loadedModelName: String? = null,
    val isGenerating: Boolean = false,
    val statusText: String = "No local model installed"
)

data class ModelEngineConfig(
    val nThreads: Int = 4,         // MediaTek Dimensity 1300 has 4 high-perf Cortex-A78 cores
    val contextSize: Int = 2048,   // Memory-safe context buffer for 8GB device
    val useGpu: Boolean = false,   // CPU inference default
    val temperature: Float = 0.7f,
    val topP: Float = 0.9f
)

interface LlmEngine {
    val modelStatus: StateFlow<ModelStatus>
    val modelState: StateFlow<LlmEngineState>
    val config: StateFlow<ModelEngineConfig>
    val isGenerating: StateFlow<Boolean>

    fun updateConfig(newConfig: ModelEngineConfig)
    suspend fun loadModel(model: GgufModel): Boolean
    suspend fun unloadModel()
    fun stopGeneration()

    /**
     * Streams generated tokens one by one as they are decoded by llama.cpp.
     */
    fun streamResponse(
        prompt: String,
        systemPrompt: String = DEFAULT_SYSTEM_PROMPT
    ): Flow<String>

    fun generateResponse(prompt: String): Flow<String> = streamResponse(prompt)

    companion object {
        const val DEFAULT_SYSTEM_PROMPT = """You are Axiom AI, a personal offline AI assistant running locally on an Android device.
You have access to supported phone tools:
- [TOOL: app_launcher, app_name: "<name>"]
- [TOOL: settings_page, page: "<wifi|bluetooth|display|battery|apps>"]
- [TOOL: set_alarm, hour: <0-23>, minute: <0-59>, message: "<label>"]
- [TOOL: search_web, query: "<query>"]
- [TOOL: prepare_message, contact: "<name>", app: "<whatsapp|telegram|sms>", text: "<body>"]
- [TOOL: dial_phone, number: "<number>"]

When the user asks you to perform a device action, invoke the tool inside brackets.
Always ask confirmation before sending any communication."""
    }
}

class LocalLlmEngine(private val context: Context) : LlmEngine {

    private val TAG = "LocalLlmEngine"

    private val _modelStatus = MutableStateFlow<ModelStatus>(ModelStatus.NoModelInstalled)
    override val modelStatus: StateFlow<ModelStatus> = _modelStatus.asStateFlow()

    private val _modelState = MutableStateFlow(LlmEngineState())
    override val modelState: StateFlow<LlmEngineState> = _modelState.asStateFlow()

    private val _config = MutableStateFlow(ModelEngineConfig())
    override val config: StateFlow<ModelEngineConfig> = _config.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    override val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val stopFlag = AtomicBoolean(false)
    private var activeModel: GgufModel? = null

    override fun updateConfig(newConfig: ModelEngineConfig) {
        _config.value = newConfig
    }

    override suspend fun loadModel(model: GgufModel): Boolean = withContext(Dispatchers.IO) {
        try {
            _modelStatus.value = ModelStatus.Loading(model.name, 0.2f)
            _modelState.value = _modelState.value.copy(
                isModelLoaded = false,
                loadedModelName = model.name,
                statusText = "Loading ${model.name} into RAM..."
            )
            Log.i(TAG, "Loading model: ${model.name}")

            if (!model.file.exists()) {
                _modelStatus.value = ModelStatus.Error("Model file does not exist on disk.")
                _modelState.value = _modelState.value.copy(statusText = "Model file not found")
                return@withContext false
            }

            _modelStatus.value = ModelStatus.Loading(model.name, 0.6f)

            val currentConfig = _config.value
            if (!NativeLlamaBridge.isNativeLoaded()) {
                val errorMsg = "Native llama.cpp library (libaxiom_llama.so) is not loaded. Cannot load model without native ARM64 inference engine."
                Log.e(TAG, errorMsg)
                _modelStatus.value = ModelStatus.Error(errorMsg)
                _modelState.value = _modelState.value.copy(
                    isModelLoaded = false,
                    statusText = "Native library missing"
                )
                return@withContext false
            }

            val success = NativeLlamaBridge.nativeLoadModel(
                model.file.absolutePath,
                currentConfig.nThreads,
                currentConfig.contextSize,
                currentConfig.useGpu
            )

            if (success) {
                activeModel = model
                _modelStatus.value = ModelStatus.ModelReady(
                    modelName = model.name,
                    filePath = model.file.absolutePath,
                    sizeMb = model.sizeBytes / (1024 * 1024)
                )
                _modelState.value = LlmEngineState(
                    isModelLoaded = true,
                    loadedModelName = model.name,
                    isGenerating = false,
                    statusText = "Model Ready: ${model.name}"
                )
                Log.i(TAG, "Model successfully loaded: ${model.name}")
                true
            } else {
                val errorMsg = "Failed to initialize native llama.cpp model context for ${model.name}. Model may be corrupted or incompatible."
                Log.e(TAG, errorMsg)
                _modelStatus.value = ModelStatus.Error(errorMsg)
                _modelState.value = _modelState.value.copy(
                    isModelLoaded = false,
                    statusText = "Context init failed"
                )
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error loading model", e)
            _modelStatus.value = ModelStatus.Error(e.message ?: "Unknown model loading error")
            _modelState.value = _modelState.value.copy(statusText = "Error: ${e.message}")
            false
        }
    }

    override suspend fun unloadModel() = withContext(Dispatchers.IO) {
        stopGeneration()
        if (NativeLlamaBridge.isNativeLoaded()) {
            NativeLlamaBridge.nativeUnloadModel()
        }
        activeModel = null
        _modelStatus.value = ModelStatus.NoModelInstalled
        _modelState.value = LlmEngineState(
            isModelLoaded = false,
            loadedModelName = null,
            isGenerating = false,
            statusText = "No local model installed"
        )
    }

    override fun stopGeneration() {
        stopFlag.set(true)
        if (NativeLlamaBridge.isNativeLoaded()) {
            NativeLlamaBridge.nativeStopGeneration()
        }
        _isGenerating.value = false
        _modelState.value = _modelState.value.copy(isGenerating = false)
    }

    override fun streamResponse(prompt: String, systemPrompt: String): Flow<String> = callbackFlow {
        stopFlag.set(false)
        _isGenerating.value = true
        _modelState.value = _modelState.value.copy(isGenerating = true)

        val status = _modelStatus.value
        if (status !is ModelStatus.ModelReady) {
            trySend("Axiom Local Engine: No local model installed.\n\nPlease open Model Manager to import a GGUF model (e.g. Qwen 2.5 1.5B or Llama 3.2 1B). All generation runs 100% on-device on your MediaTek Dimensity 1300.")
            close()
            _isGenerating.value = false
            _modelState.value = _modelState.value.copy(isGenerating = false)
            return@callbackFlow
        }

        withContext(Dispatchers.IO) {
            try {
                if (NativeLlamaBridge.isNativeLoaded()) {
                    val formattedPrompt = "<|im_start|>system\n$systemPrompt<|im_end|>\n<|im_start|>user\n$prompt<|im_end|>\n<|im_start|>assistant\n"
                    val success = NativeLlamaBridge.nativeGenerateTokens(formattedPrompt, object : NativeTokenCallback {
                        override fun onTokenGenerated(token: String) {
                            if (!stopFlag.get() && isActive) {
                                trySend(token)
                            }
                        }
                    })
                    if (!success) {
                        trySend("\n[Inference Error: Native llama.cpp decode failed or was interrupted.]")
                    }
                } else {
                    // Honest error reporting when native ARM64 library is not loaded
                    trySend("Axiom Native Engine: libaxiom_llama.so is not compiled for this runtime. Native ARM64 (arm64-v8a) llama.cpp build is required for on-device GGUF execution.")
                }
            } catch (e: CancellationException) {
                Log.i(TAG, "Generation cancelled by user")
            } catch (e: Exception) {
                Log.e(TAG, "Inference error", e)
                trySend("\n[Inference Error: ${e.localizedMessage}]")
            } finally {
                _isGenerating.value = false
                _modelState.value = _modelState.value.copy(isGenerating = false)
                close()
            }
        }

        awaitClose {
            stopGeneration()
        }
    }.flowOn(Dispatchers.IO)
}
