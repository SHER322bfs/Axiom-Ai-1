package com.axiomai.app

import android.app.Application
import com.axiomai.app.data.local.AppDatabase
import com.axiomai.app.data.repository.ChatRepository
import com.axiomai.app.data.repository.ChatRepositoryImpl
import com.axiomai.app.domain.engine.LocalLlmEngine
import com.axiomai.app.domain.model.ModelManager
import com.axiomai.app.domain.tools.ToolRegistry
import com.axiomai.app.domain.voice.VoiceInputManager
import com.axiomai.app.domain.voice.VoiceOutputManager
import com.axiomai.app.domain.voice.WakeWordManager

class AxiomApplication : Application() {

    val database: AppDatabase by lazy {
        AppDatabase.getDatabase(this)
    }

    val chatRepository: ChatRepository by lazy {
        ChatRepositoryImpl(database.chatDao())
    }

    val modelManager: ModelManager by lazy {
        ModelManager(this)
    }

    val llmEngine: LocalLlmEngine by lazy {
        LocalLlmEngine(this)
    }

    val voiceInputManager: VoiceInputManager by lazy {
        VoiceInputManager(this)
    }

    val voiceOutputManager: VoiceOutputManager by lazy {
        VoiceOutputManager(this)
    }

    val wakeWordManager: WakeWordManager by lazy {
        WakeWordManager(this)
    }

    val toolRegistry: ToolRegistry by lazy {
        ToolRegistry(this)
    }

    override fun onCreate() {
        super.onCreate()
    }
}
