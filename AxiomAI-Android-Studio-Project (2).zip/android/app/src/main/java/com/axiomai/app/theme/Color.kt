package com.axiomai.app.theme

import androidx.compose.ui.graphics.Color

// Obsidian & Void dark palette for Axiom AI
val VoidBlack = Color(0xFF0B0D13)
val SurfaceDark = Color(0xFF131722)
val CardDark = Color(0xFF1B202E)
val CardBorderDark = Color(0xFF282F44)

val PrimaryViolet = Color(0xFF7C3AED)
val PrimaryVioletHover = Color(0xFF6D28D9)
val SecondaryCyan = Color(0xFF06B6D4)
val AccentPurpleLight = Color(0xFFA78BFA)

val TextPrimaryDark = Color(0xFFF3F4F6)
val TextSecondaryDark = Color(0xFF9CA3AF)
val TextMutedDark = Color(0xFF6B7280)

val UserBubbleDark = Color(0xFF252A3A)
val AssistantBubbleDark = Color(0xFF161B26)
val AssistantBubbleBorder = Color(0xFF232A3B)

val StatusWarning = Color(0xFFF59E0B)
val StatusWarningBg = Color(0x26F59E0B)
val StatusSuccess = Color(0xFF10B981)
val StatusSuccessBg = Color(0x2610B981)
