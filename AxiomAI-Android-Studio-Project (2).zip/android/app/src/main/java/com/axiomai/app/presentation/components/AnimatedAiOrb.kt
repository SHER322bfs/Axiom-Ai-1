package com.axiomai.app.presentation.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

/**
 * State of the Axiom AI Neural Orb
 */
sealed class OrbState {
    object Idle : OrbState()
    data class Listening(val rmsDb: Float = 0f) : OrbState()
    object Thinking : OrbState()
    data class Speaking(val audioLevel: Float = 0.5f) : OrbState()
    data class Error(val message: String) : OrbState()
}

/**
 * Animated AI Orb rendered on Jetpack Compose Canvas.
 * Reacts smoothly to Voice Input RMS, LLM Inference Thinking states, and TTS Vocalization.
 */
@Composable
fun AnimatedAiOrb(
    state: OrbState,
    modifier: Modifier = Modifier,
    size: Dp = 220.dp,
    onClick: (() -> Unit)? = null
) {
    val infiniteTransition = rememberInfiniteTransition(label = "AxiomOrbLoop")

    // Slow atmospheric pulse
    val idlePulse by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "IdlePulse"
    )

    // Continuous rotation for outer magnetic fields
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (state is OrbState.Thinking) 1600 else 8000,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "OrbRotation"
    )

    // Fast shimmer for thinking state
    val shimmerPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ShimmerPhase"
    )

    // Smooth reactive scale for RMS microphone decibels
    val animatedRms = remember { Animatable(0f) }
    LaunchedEffect(state) {
        when (state) {
            is OrbState.Listening -> {
                // RMS is typically -2 to 10 on Android SpeechRecognizer
                val normalized = (state.rmsDb.coerceIn(0f, 12f) / 12f)
                animatedRms.animateTo(
                    targetValue = normalized,
                    animationSpec = tween(durationMillis = 80, easing = LinearEasing)
                )
            }
            is OrbState.Speaking -> {
                animatedRms.animateTo(
                    targetValue = state.audioLevel.coerceIn(0.2f, 1f),
                    animationSpec = tween(durationMillis = 120, easing = FastOutSlowInEasing)
                )
            }
            else -> {
                animatedRms.animateTo(0f, animationSpec = tween(durationMillis = 300))
            }
        }
    }

    // Color definitions based on state
    val (primaryGlow, secondaryGlow, coreGlow) = when (state) {
        is OrbState.Idle -> Triple(
            Color(0xFF7C3AED), // Royal Violet
            Color(0xFF2563EB), // Electric Blue
            Color(0xFFA78BFA)  // Soft Lavender
        )
        is OrbState.Listening -> Triple(
            Color(0xFF06B6D4), // Cyan
            Color(0xFF8B5CF6), // Purple
            Color(0xFF67E8F9)  // Bright Cyan Core
        )
        is OrbState.Thinking -> Triple(
            Color(0xFFEC4899), // Magenta
            Color(0xFF8B5CF6), // Violet
            Color(0xFFF472B6)  // Radiant Pink
        )
        is OrbState.Speaking -> Triple(
            Color(0xFF10B981), // Emerald
            Color(0xFF06B6D4), // Cyan
            Color(0xFF34D399)  // Bright Emerald
        )
        is OrbState.Error -> Triple(
            Color(0xFFEF4444), // Crimson
            Color(0xFFF59E0B), // Amber
            Color(0xFFFCA5A5)  // Soft Red
        )
    }

    Box(
        modifier = modifier
            .size(size)
            .then(
                if (onClick != null) {
                    Modifier.clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onClick
                    )
                } else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.toPx() / 2f, size.toPx() / 2f)
            val baseRadius = size.toPx() * 0.32f
            val dynamicScale = idlePulse + (animatedRms.value * 0.45f)
            val currentRadius = baseRadius * dynamicScale

            // 1. Outermost Diffuse Nebula Glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryGlow.copy(alpha = 0.45f),
                        secondaryGlow.copy(alpha = 0.18f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = currentRadius * 1.7f
                ),
                radius = currentRadius * 1.7f,
                center = center
            )

            // 2. Audio Reaction Shockwaves (when listening or speaking)
            if (animatedRms.value > 0.05f) {
                val waveRadius = currentRadius * (1.15f + animatedRms.value * 0.5f)
                drawCircle(
                    color = primaryGlow.copy(alpha = (1f - animatedRms.value * 0.7f).coerceIn(0.1f, 0.6f)),
                    radius = waveRadius,
                    center = center,
                    style = Stroke(
                        width = 2.5f * (1f + animatedRms.value),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 15f), 0f)
                    )
                )
            }

            // 3. Rotating Gyroscopic Orbital Rings
            val ringRadius = currentRadius * 1.25f
            val radAngle = Math.toRadians(rotationAngle.toDouble()).toFloat()

            // Ring 1 (Horizontal tilt)
            drawCircle(
                brush = Brush.sweepGradient(
                    colors = listOf(
                        primaryGlow.copy(alpha = 0.8f),
                        Color.Transparent,
                        secondaryGlow.copy(alpha = 0.9f),
                        Color.Transparent,
                        primaryGlow.copy(alpha = 0.8f)
                    ),
                    center = center
                ),
                radius = ringRadius,
                center = center,
                style = Stroke(width = 2.0f)
            )

            // Ring 2 (Dashed Counter-Rotation)
            drawCircle(
                color = secondaryGlow.copy(alpha = 0.4f),
                radius = ringRadius * 0.92f,
                center = center,
                style = Stroke(
                    width = 1.5f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 20f), -rotationAngle * 2f)
                )
            )

            // 4. Orbiting Quantum Nodes
            val nodeCount = if (state is OrbState.Thinking) 6 else 4
            for (i in 0 until nodeCount) {
                val nodeAngle = radAngle + (i * (2 * Math.PI / nodeCount).toFloat())
                val nx = center.x + (ringRadius * cos(nodeAngle))
                val ny = center.y + (ringRadius * sin(nodeAngle))
                drawCircle(
                    color = coreGlow,
                    radius = if (state is OrbState.Thinking) 4.5f else 3.2f,
                    center = Offset(nx, ny)
                )
            }

            // 5. Dense Energy Core
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.95f),
                        coreGlow.copy(alpha = 0.9f),
                        primaryGlow.copy(alpha = 0.85f),
                        secondaryGlow.copy(alpha = 0.4f),
                        Color.Transparent
                    ),
                    center = center.copy(
                        x = center.x - (currentRadius * 0.12f),
                        y = center.y - (currentRadius * 0.15f)
                    ),
                    radius = currentRadius
                ),
                radius = currentRadius,
                center = center
            )

            // 6. Central Specular Highlight Reflection
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.75f),
                        Color.Transparent
                    ),
                    center = center.copy(
                        x = center.x - (currentRadius * 0.28f),
                        y = center.y - (currentRadius * 0.32f)
                    ),
                    radius = currentRadius * 0.45f
                ),
                radius = currentRadius * 0.45f,
                center = center.copy(
                    x = center.x - (currentRadius * 0.28f),
                    y = center.y - (currentRadius * 0.32f)
                )
            )
        }
    }
}
