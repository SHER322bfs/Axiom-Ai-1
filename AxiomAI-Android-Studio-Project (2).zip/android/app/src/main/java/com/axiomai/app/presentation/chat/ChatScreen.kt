package com.axiomai.app.presentation.chat

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.axiomai.app.data.local.ChatMessageEntity
import com.axiomai.app.data.local.MessageSender
import com.axiomai.app.domain.engine.ModelStatus
import com.axiomai.app.domain.voice.VoiceInputState
import com.axiomai.app.theme.*
import kotlinx.coroutines.flow.collectLatest
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    onNavigateToSettings: () -> Unit
) {
    val context = LocalContext.current
    val messages by viewModel.messages.collectAsState()
    val modelStatus by viewModel.modelStatus.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val streamingText by viewModel.streamingText.collectAsState()
    val voiceState by viewModel.voiceState.collectAsState()
    val isSpeaking by viewModel.isSpeaking.collectAsState()
    val isHybridOnline by viewModel.isHybridOnline.collectAsState()
    val pendingConfirmation by viewModel.pendingConfirmation.collectAsState()

    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    // Handle toast events
    LaunchedEffect(Unit) {
        viewModel.uiEvents.collectLatest { event ->
            when (event) {
                is ChatUiEvent.ShowToast -> {
                    Toast.makeText(context, event.message, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // Auto-scroll when messages or streaming text changes
    LaunchedEffect(messages.size, streamingText) {
        val total = messages.size + (if (streamingText != null) 1 else 0)
        if (total > 0) {
            listState.animateScrollToItem(total - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "Axiom AI",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark
                            )
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (isHybridOnline) SecondaryCyan.copy(alpha = 0.2f) else PrimaryViolet.copy(alpha = 0.2f),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isHybridOnline) SecondaryCyan.copy(alpha = 0.4f) else PrimaryViolet.copy(alpha = 0.4f)
                                )
                            ) {
                                Text(
                                    text = if (isHybridOnline) "HYBRID" else "OFFLINE",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isHybridOnline) SecondaryCyan else AccentPurpleLight,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Text(
                            text = when (val s = modelStatus) {
                                is ModelStatus.NoModelInstalled -> "No local model installed"
                                is ModelStatus.ModelReady -> "${s.modelName} (${s.sizeMb} MB)"
                                is ModelStatus.Loading -> "Loading ${s.modelName}..."
                                is ModelStatus.Error -> "Engine error"
                            },
                            style = MaterialTheme.typography.labelMedium,
                            fontSize = 11.sp,
                            color = when (modelStatus) {
                                is ModelStatus.NoModelInstalled -> StatusWarning
                                is ModelStatus.ModelReady -> StatusSuccess
                                else -> TextMutedDark
                            }
                        )
                    }
                },
                actions = {
                    // Online/Offline toggle
                    IconButton(onClick = { viewModel.toggleHybridMode() }) {
                        Icon(
                            imageVector = if (isHybridOnline) Icons.Default.Cloud else Icons.Default.CloudOff,
                            contentDescription = "Toggle Hybrid Mode",
                            tint = if (isHybridOnline) SecondaryCyan else TextMutedDark
                        )
                    }

                    // Settings Icon
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = TextSecondaryDark
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = VoidBlack)
            )
        },
        containerColor = VoidBlack
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .imePadding()
        ) {
            // Chat Feed
            if (messages.isEmpty() && streamingText == null) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Surface(
                            modifier = Modifier.size(64.dp),
                            shape = CircleShape,
                            color = SurfaceDark,
                            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorderDark)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "A",
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryViolet
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Axiom AI Personal Assistant",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "100% on-device AI optimized for your Vivo V25 MediaTek Dimensity 1300.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondaryDark,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Surface(
                            color = when (modelStatus) {
                                is ModelStatus.NoModelInstalled -> StatusWarningBg
                                else -> StatusSuccessBg
                            },
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (modelStatus is ModelStatus.NoModelInstalled) StatusWarning.copy(alpha = 0.3f) else StatusSuccess.copy(alpha = 0.3f)
                            )
                        ) {
                            Text(
                                text = when (modelStatus) {
                                    is ModelStatus.NoModelInstalled -> "Status: No local model installed"
                                    is ModelStatus.ModelReady -> "Status: Local GGUF Ready"
                                    else -> "Status: Initializing"
                                },
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                style = MaterialTheme.typography.labelMedium,
                                color = if (modelStatus is ModelStatus.NoModelInstalled) StatusWarning else StatusSuccess
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        TextButton(onClick = onNavigateToSettings) {
                            Text("Open Model Manager to import GGUF", color = AccentPurpleLight)
                        }
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(messages, key = { it.id }) { message ->
                        ChatMessageItem(
                            message = message,
                            onSpeak = { viewModel.speakMessage(message.content) },
                            isSpeaking = isSpeaking
                        )
                    }

                    // Live Streaming Token Bubble
                    if (streamingText != null) {
                        item(key = "streaming_bubble") {
                            StreamingMessageItem(text = streamingText ?: "")
                        }
                    }
                }
            }

            // Voice Listening Waveform Banner (Active when microphone is on)
            AnimatedVisibility(
                visible = voiceState is VoiceInputState.Listening || voiceState is VoiceInputState.Processing,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
            ) {
                Surface(
                    color = SurfaceDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryViolet.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFEF4444))
                            )
                            Text(
                                text = if (voiceState is VoiceInputState.Processing) "Processing speech..." else "Listening (English / Hindi)...",
                                color = TextPrimaryDark,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Button(
                            onClick = { viewModel.stopVoiceInput() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Text("Stop", fontSize = 12.sp, color = Color.White)
                        }
                    }
                }
            }

            // Bottom Input Bar
            Surface(
                color = SurfaceDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Voice input button
                    IconButton(
                        onClick = { viewModel.startVoiceInput(context) },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(if (voiceState is VoiceInputState.Listening) PrimaryViolet else Color.Transparent)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Voice Input",
                            tint = if (voiceState is VoiceInputState.Listening) Color.White else PrimaryViolet
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Text Input Field
                    TextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = {
                            Text(
                                text = "Message Axiom or ask a question...",
                                color = TextMutedDark,
                                fontSize = 14.sp
                            )
                        },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = CardDark,
                            unfocusedContainerColor = CardDark,
                            focusedTextColor = TextPrimaryDark,
                            unfocusedTextColor = TextPrimaryDark,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 44.dp, max = 120.dp)
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    // Stop Generation Button OR Send Button
                    if (isGenerating) {
                        IconButton(
                            onClick = { viewModel.stopGeneration() },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFEF4444))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stop,
                                contentDescription = "Stop Generation",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    } else {
                        IconButton(
                            onClick = {
                                if (inputText.isNotBlank()) {
                                    viewModel.sendMessage(inputText, context)
                                    inputText = ""
                                }
                            },
                            enabled = inputText.isNotBlank(),
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(
                                    if (inputText.isNotBlank()) PrimaryViolet else CardBorderDark
                                )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "Send",
                                tint = if (inputText.isNotBlank()) Color.White else TextMutedDark,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    // Explicit Safety Confirmation Dialog (Never sends messages or places calls without user confirmation!)
    if (pendingConfirmation != null) {
        val conf = pendingConfirmation!!
        AlertDialog(
            onDismissRequest = { viewModel.dismissPendingAction() },
            title = {
                Text(text = conf.title, fontWeight = FontWeight.Bold, color = TextPrimaryDark)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = "Axiom AI requires your explicit confirmation before dispatching this action:", color = TextSecondaryDark, fontSize = 13.sp)
                    Surface(
                        color = CardDark,
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorderDark),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(text = "Channel: ${conf.appChannel.uppercase()}", fontWeight = FontWeight.Bold, color = PrimaryViolet, fontSize = 12.sp)
                            Text(text = "Recipient: ${conf.recipient}", color = TextPrimaryDark, fontSize = 12.sp)
                            Text(text = "Message: \"${conf.messageText}\"", color = TextSecondaryDark, fontSize = 12.sp)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.confirmPendingAction(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryViolet)
                ) {
                    Text("Confirm & Send")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { viewModel.dismissPendingAction() }) {
                    Text("Cancel")
                }
            },
            containerColor = SurfaceDark
        )
    }
}

@Composable
fun ChatMessageItem(
    message: ChatMessageEntity,
    onSpeak: () -> Unit,
    isSpeaking: Boolean
) {
    val isUser = message.sender == MessageSender.USER
    val timeFormat = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val formattedTime = remember(message.timestamp) { timeFormat.format(Date(message.timestamp)) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Surface(
            color = if (isUser) UserBubbleDark else AssistantBubbleDark,
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (isUser) PrimaryViolet.copy(alpha = 0.3f) else AssistantBubbleBorder
            ),
            modifier = Modifier.widthIn(max = 310.dp)
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                if (!isUser) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Axiom Local",
                            style = MaterialTheme.typography.labelMedium,
                            color = PrimaryViolet,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.sp
                        )
                        IconButton(
                            onClick = onSpeak,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "Speak response",
                                tint = AccentPurpleLight,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
                Text(
                    text = message.content,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimaryDark,
                    lineHeight = 20.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = formattedTime,
                    style = MaterialTheme.typography.labelMedium,
                    color = TextMutedDark,
                    fontSize = 10.sp,
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }
    }
}

@Composable
fun StreamingMessageItem(text: String) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.Start
    ) {
        Surface(
            color = AssistantBubbleDark,
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryViolet.copy(alpha = 0.5f)),
            modifier = Modifier.widthIn(max = 310.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Axiom Local (Generating...)",
                    style = MaterialTheme.typography.labelMedium,
                    color = PrimaryViolet,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (text.isEmpty()) "• Thinking..." else "$text ▋",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimaryDark,
                    lineHeight = 20.sp
                )
            }
        }
    }
}
