package com.axiomai.app.domain.model

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import android.util.Log
import com.axiomai.app.domain.engine.NativeLlamaBridge
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

data class GgufValidationResult(
    val isValid: Boolean,
    val version: Int = 0,
    val tensorCount: Long = 0,
    val architecture: String? = null,
    val contextLength: Int = 2048,
    val estimatedRamMb: Long = 0,
    val isCompatibleWithDevice: Boolean = true,
    val errorMessage: String? = null
)

data class GgufModel(
    val id: String,
    val name: String,
    val file: File,
    val sizeBytes: Long,
    val quantType: String,
    val version: Int = 3,
    val tensorCount: Long = 0,
    val architecture: String = "transformer",
    val estimatedRamMb: Long = 0,
    val isActive: Boolean = false
) {
    val sizeFormatted: String
        get() = when {
            sizeBytes >= 1024 * 1024 * 1024 -> String.format("%.2f GB", sizeBytes.toDouble() / (1024 * 1024 * 1024))
            sizeBytes >= 1024 * 1024 -> String.format("%.1f MB", sizeBytes.toDouble() / (1024 * 1024))
            else -> "$sizeBytes bytes"
        }
}

data class DeviceResources(
    val totalRamMb: Long,
    val availableRamMb: Long,
    val freeStorageMb: Long,
    val isRamSufficient: Boolean,
    val recommendedQuant: String = "Q4_K_M"
)

data class RecommendedModel(
    val title: String,
    val filename: String,
    val parameters: String,
    val quant: String,
    val sizeMb: Long,
    val minRamMb: Long,
    val downloadUrl: String,
    val description: String
)

class ModelManager(private val context: Context) {

    private val TAG = "ModelManager"

    val modelsDir: File by lazy {
        File(context.filesDir, "models").apply {
            if (!exists()) mkdirs()
        }
    }

    private val _installedModels = MutableStateFlow<List<GgufModel>>(emptyList())
    val installedModels: StateFlow<List<GgufModel>> = _installedModels.asStateFlow()

    private val _activeModel = MutableStateFlow<GgufModel?>(null)
    val activeModel: StateFlow<GgufModel?> = _activeModel.asStateFlow()

    val recommendedModels = listOf(
        RecommendedModel(
            title = "Qwen 2.5 1.5B Instruct",
            filename = "qwen2.5-1.5b-instruct-q4_k_m.gguf",
            parameters = "1.5 Billion",
            quant = "Q4_K_M",
            sizeMb = 986,
            minRamMb = 1800,
            downloadUrl = "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF",
            description = "High reasoning capability, outstanding multilingual & Hinglish support. Optimal for Vivo V25."
        ),
        RecommendedModel(
            title = "Llama 3.2 1B Instruct",
            filename = "llama-3.2-1b-instruct-q4_k_m.gguf",
            parameters = "1.2 Billion",
            quant = "Q4_K_M",
            sizeMb = 770,
            minRamMb = 1400,
            downloadUrl = "https://huggingface.co/bartowski/Llama-3.2-1B-Instruct-GGUF",
            description = "Extremely lightweight and fast on ARM64 Cortex-A78 cores with low thermal footprint."
        ),
        RecommendedModel(
            title = "SmolLM2 1.7B Instruct",
            filename = "smollm2-1.7b-instruct-q4_k_m.gguf",
            parameters = "1.7 Billion",
            quant = "Q4_K_M",
            sizeMb = 1050,
            minRamMb = 2000,
            downloadUrl = "https://huggingface.co/HuggingFaceTB/SmolLM2-1.7B-Instruct-GGUF",
            description = "Optimized for on-device reasoning and tool assistance."
        )
    )

    init {
        refreshInstalledModels()
    }

    fun getDeviceResources(): DeviceResources {
        val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        actManager.getMemoryInfo(memInfo)

        val totalRamMb = memInfo.totalMem / (1024 * 1024)
        val availRamMb = memInfo.availMem / (1024 * 1024)

        val stat = StatFs(Environment.getDataDirectory().path)
        val freeStorageMb = (stat.availableBlocksLong * stat.blockSizeLong) / (1024 * 1024)

        // Vivo V25 has 8GB RAM, which easily supports 1B-3B models with Q4 quantization
        return DeviceResources(
            totalRamMb = totalRamMb,
            availableRamMb = availRamMb,
            freeStorageMb = freeStorageMb,
            isRamSufficient = availRamMb >= 1200
        )
    }

    fun refreshInstalledModels() {
        val files = modelsDir.listFiles { file ->
            file.isFile && file.extension.lowercase() == "gguf"
        } ?: emptyArray()

        val list = files.map { file ->
            val validation = validateGgufFile(file)
            val quantGuess = when {
                file.name.contains("q4_k_m", ignoreCase = true) -> "Q4_K_M"
                file.name.contains("q4_0", ignoreCase = true) -> "Q4_0"
                file.name.contains("q8_0", ignoreCase = true) -> "Q8_0"
                file.name.contains("q5_k_m", ignoreCase = true) -> "Q5_K_M"
                else -> "GGUF Quant"
            }
            GgufModel(
                id = file.absolutePath,
                name = file.name,
                file = file,
                sizeBytes = file.length(),
                quantType = quantGuess,
                version = validation.version,
                tensorCount = validation.tensorCount,
                architecture = validation.architecture ?: "transformer",
                estimatedRamMb = validation.estimatedRamMb,
                isActive = _activeModel.value?.id == file.absolutePath
            )
        }

        _installedModels.value = list
        if (_activeModel.value != null && list.none { it.id == _activeModel.value?.id }) {
            _activeModel.value = null
        }
    }

    /**
     * Audits and validates GGUF magic, header version, tensor count, and RAM compatibility.
     * Uses native C++ validation when libaxiom_llama.so is loaded, with safe byte parser fallback.
     */
    fun validateGgufFile(file: File): GgufValidationResult {
        if (!file.exists() || file.length() < 32) {
            return GgufValidationResult(isValid = false, errorMessage = "File too small or does not exist.")
        }

        if (NativeLlamaBridge.isNativeLoaded()) {
            try {
                val jsonStr = NativeLlamaBridge.nativeValidateGguf(file.absolutePath)
                val json = JSONObject(jsonStr)
                return GgufValidationResult(
                    isValid = json.optBoolean("valid", false),
                    version = json.optInt("version", 3),
                    tensorCount = json.optLong("tensorCount", 0),
                    architecture = json.optString("architecture", "unknown"),
                    contextLength = json.optInt("contextLength", 2048),
                    estimatedRamMb = json.optLong("estimatedRamMb", file.length() / (1024 * 1024) + 300),
                    isCompatibleWithDevice = json.optBoolean("compatible", true),
                    errorMessage = json.optString("error", null)
                )
            } catch (e: Exception) {
                Log.w(TAG, "Native validation error: ${e.message}. Using binary header fallback.")
            }
        }

        // Binary header fallback validation
        try {
            FileInputStream(file).use { stream ->
                val header = ByteArray(24)
                val read = stream.read(header)
                if (read < 24) return GgufValidationResult(isValid = false, errorMessage = "Header incomplete")

                val magicStr = String(header, 0, 4, Charsets.US_ASCII)
                if (magicStr != "GGUF") {
                    return GgufValidationResult(isValid = false, errorMessage = "Invalid GGUF magic bytes (found '$magicStr')")
                }

                val version = (header[4].toInt() and 0xFF) or ((header[5].toInt() and 0xFF) shl 8)
                val tensorCount = ((header[8].toLong() and 0xFF)) or ((header[9].toLong() and 0xFF) shl 8)

                val fileMb = file.length() / (1024 * 1024)
                val estimatedRamMb = fileMb + 350
                val compatible = estimatedRamMb <= 5200 // Vivo V25 5.2GB free RAM budget

                return GgufValidationResult(
                    isValid = true,
                    version = version,
                    tensorCount = tensorCount,
                    estimatedRamMb = estimatedRamMb,
                    isCompatibleWithDevice = compatible,
                    errorMessage = if (!compatible) "Model requires ~${estimatedRamMb}MB RAM, exceeding Vivo V25 limit" else null
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "GGUF validation failed for ${file.name}", e)
            return GgufValidationResult(isValid = false, errorMessage = e.localizedMessage)
        }
    }

    /**
     * Imports a model from an Android SAF content URI into app-private storage.
     * Emits copy progress percentage (0.0f to 1.0f).
     */
    fun importModelFromUri(uri: Uri, displayName: String): Flow<Float> = flow {
        val sanitizedName = if (displayName.endsWith(".gguf", ignoreCase = true)) {
            displayName
        } else {
            "$displayName.gguf"
        }

        val destinationFile = File(modelsDir, sanitizedName)
        val contentResolver = context.contentResolver

        emit(0.05f)

        withContext(Dispatchers.IO) {
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destinationFile).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var bytesCopied = 0L
                    var bytesRead: Int
                    val totalBytes = contentResolver.openFileDescriptor(uri, "r")?.statSize ?: -1L

                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        output.write(buffer, 0, bytesRead)
                        bytesCopied += bytesRead
                        if (totalBytes > 0) {
                            val progress = (bytesCopied.toFloat() / totalBytes.toFloat()).coerceIn(0.1f, 0.95f)
                        }
                    }
                }
            } ?: throw IllegalStateException("Could not open input stream from chosen document URI.")

            // Verify the copied file is truly a compatible GGUF file
            val validation = validateGgufFile(destinationFile)
            if (!validation.isValid) {
                destinationFile.delete()
                throw IllegalArgumentException("The selected file is not a valid GGUF model: ${validation.errorMessage}")
            }
            if (!validation.isCompatibleWithDevice) {
                destinationFile.delete()
                throw IllegalArgumentException("Incompatible model: ${validation.errorMessage}")
            }
        }

        emit(1.0f)
        refreshInstalledModels()
    }.flowOn(Dispatchers.IO)

    fun setActiveModel(model: GgufModel) {
        _activeModel.value = model
        refreshInstalledModels()
    }

    fun deactivateModel() {
        _activeModel.value = null
        refreshInstalledModels()
    }

    fun deleteModel(model: GgufModel): Boolean {
        if (_activeModel.value?.id == model.id) {
            deactivateModel()
        }
        val deleted = model.file.delete()
        refreshInstalledModels()
        return deleted
    }
}
