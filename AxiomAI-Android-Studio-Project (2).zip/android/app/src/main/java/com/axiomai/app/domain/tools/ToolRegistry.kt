package com.axiomai.app.domain.tools

import android.content.Context
import android.util.Log

class ToolRegistry(private val context: Context) {

    private val TAG = "ToolRegistry"

    private val tools: Map<String, AxiomTool> = listOf(
        AppLauncherTool(),
        SettingsPageTool(),
        AlarmReminderTool(),
        DialerTool(),
        WebSearchTool(),
        CommunicationTool(),
        NotificationReaderTool()
    ).associateBy { it.id }

    fun getTool(id: String): AxiomTool? = tools[id]

    /**
     * Parses generated text to check if the LLM invoked any device tools.
     * Format: [TOOL: id, param1: "val", param2: "val"]
     */
    suspend fun executeToolsInText(text: String): ToolResult? {
        val toolRegex = Regex("\\[TOOL:\\s*([a-zA-Z0-9_]+)(?:,\\s*([^\\]]+))?\\]")
        val match = toolRegex.find(text) ?: return null

        val toolId = match.groupValues[1].trim()
        val paramsString = match.groupValues.getOrNull(2) ?: ""

        val tool = getTool(toolId) ?: return ToolResult(false, "Unknown tool: $toolId")

        // Parse key-value parameters: param: "value" or param: value
        val params = mutableMapOf<String, String>()
        val paramRegex = Regex("([a-zA-Z0-9_]+)\\s*:\\s*(?:\"([^\"]*)\"|([^,]+))")
        paramRegex.findAll(paramsString).forEach { pMatch ->
            val key = pMatch.groupValues[1].trim()
            val value = pMatch.groupValues[2].ifEmpty { pMatch.groupValues[3].trim() }
            params[key] = value
        }

        Log.i(TAG, "Executing tool '$toolId' with parameters: $params")
        return tool.execute(context, params)
    }
}
