package com.axiomai.app.presentation.modelmanager

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.axiomai.app.domain.engine.LlmEngine
import com.axiomai.app.domain.engine.ModelStatus
import com.axiomai.app.domain.model.DeviceResources
import com.axiomai.app.domain.model.GgufModel
import com.axiomai.app.domain.model.ModelManager
import com.axiomai.app.domain.model.RecommendedModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class ModelManagerUiEvent {
    data class ShowToast(val message: String) : ModelManagerUiEvent()
}

class ModelManagerViewModel(
    val modelManager: ModelManager,
    private val llmEngine: LlmEngine
) : ViewModel() {

    val installedModels: StateFlow<List<GgufModel>> = modelManager.installedModels
    val activeModel: StateFlow<GgufModel?> = modelManager.activeModel
    val modelStatus: StateFlow<ModelStatus> = llmEngine.modelStatus

    private val _deviceResources = MutableStateFlow(modelManager.getDeviceResources())
    val deviceResources: StateFlow<DeviceResources> = _deviceResources.asStateFlow()

    private val _importProgress = MutableStateFlow<Float?>(null)
    val importProgress: StateFlow<Float?> = _importProgress.asStateFlow()

    private val _uiEvents = MutableSharedFlow<ModelManagerUiEvent>()
    val uiEvents = _uiEvents.asSharedFlow()

    val recommendedModels: List<RecommendedModel> = modelManager.recommendedModels

    fun refresh() {
        modelManager.refreshInstalledModels()
        _deviceResources.value = modelManager.getDeviceResources()
    }

    fun importModel(uri: Uri, displayName: String) {
        viewModelScope.launch {
            try {
                _importProgress.value = 0.05f
                modelManager.importModelFromUri(uri, displayName).collect { progress ->
                    _importProgress.value = progress
                }
                _importProgress.value = null
                _uiEvents.emit(ModelManagerUiEvent.ShowToast("Successfully imported $displayName into app storage"))
                refresh()
            } catch (e: Exception) {
                _importProgress.value = null
                _uiEvents.emit(ModelManagerUiEvent.ShowToast("Import failed: ${e.localizedMessage}"))
            }
        }
    }

    fun activateModel(model: GgufModel) {
        viewModelScope.launch {
            modelManager.setActiveModel(model)
            val success = llmEngine.loadModel(model)
            if (success) {
                _uiEvents.emit(ModelManagerUiEvent.ShowToast("Loaded ${model.name} into offline engine"))
            } else {
                _uiEvents.emit(ModelManagerUiEvent.ShowToast("Failed to load model into memory"))
            }
        }
    }

    fun deactivateModel() {
        viewModelScope.launch {
            modelManager.deactivateModel()
            llmEngine.unloadModel()
            _uiEvents.emit(ModelManagerUiEvent.ShowToast("Model unloaded from memory"))
        }
    }

    fun deleteModel(model: GgufModel) {
        viewModelScope.launch {
            if (activeModel.value?.id == model.id) {
                llmEngine.unloadModel()
            }
            val deleted = modelManager.deleteModel(model)
            if (deleted) {
                _uiEvents.emit(ModelManagerUiEvent.ShowToast("Deleted ${model.name}"))
            } else {
                _uiEvents.emit(ModelManagerUiEvent.ShowToast("Could not delete ${model.name}"))
            }
            refresh()
        }
    }
}
