package com.axiomai.app.data.repository

import com.axiomai.app.data.local.ChatDao
import com.axiomai.app.data.local.ChatMessageEntity
import com.axiomai.app.data.local.MessageSender
import kotlinx.coroutines.flow.Flow

interface ChatRepository {
    fun getMessages(): Flow<List<ChatMessageEntity>>
    suspend fun saveMessage(sender: MessageSender, content: String): Long
    suspend fun clearHistory()
}

class ChatRepositoryImpl(
    private val chatDao: ChatDao
) : ChatRepository {

    override fun getMessages(): Flow<List<ChatMessageEntity>> =
        chatDao.getAllMessages()

    override suspend fun saveMessage(sender: MessageSender, content: String): Long {
        val entity = ChatMessageEntity(
            sender = sender,
            content = content,
            timestamp = System.currentTimeMillis()
        )
        return chatDao.insertMessage(entity)
    }

    override suspend fun clearHistory() {
        chatDao.clearAllMessages()
    }
}
