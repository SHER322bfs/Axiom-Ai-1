package com.axiomai.app.presentation.modelmanager

import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.axiomai.app.domain.engine.ModelStatus
import com.axiomai.app.domain.model.GgufModel
import com.axiomai.app.theme.*
import kotlinx.coroutines.flow.collectLatest

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModelManagerScreen(
    viewModel: ModelManagerViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val installedModels by viewModel.installedModels.collectAsState()
    val activeModel by viewModel.activeModel.collectAsState()
    val modelStatus by viewModel.modelStatus.collectAsState()
    val deviceResources by viewModel.deviceResources.collectAsState()
    val importProgress by viewModel.importProgress.collectAsState()

    var modelToDelete by remember { mutableStateOf<GgufModel?>(null) }

    // SAF Document Picker launcher for GGUF files
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            var fileName = "imported_model.gguf"
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && nameIndex != -1) {
                    fileName = cursor.getString(nameIndex)
                }
            }
            viewModel.importModel(uri, fileName)
        }
    }

    LaunchedEffect(Unit) {
        viewModel.refresh()
        viewModel.uiEvents.collectLatest { event ->
            when (event) {
                is ModelManagerUiEvent.ShowToast -> {
                    Toast.makeText(context, event.message, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Model Manager",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimaryDark
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.refresh() }) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh",
                            tint = TextSecondaryDark
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = VoidBlack)
            )
        },
        containerColor = VoidBlack
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Hardware Specs Card (Vivo V25 Dimensity 1300)
            Surface(
                color = SurfaceDark,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, CardBorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Target Device Hardware",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                        Text(
                            text = "ARM64 · 8-Core",
                            style = MaterialTheme.typography.labelMedium,
                            color = AccentPurpleLight
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(
                            color = CardDark,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("RAM (Device)", style = MaterialTheme.typography.labelMedium, color = TextMutedDark)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    "${deviceResources.availableRamMb} MB Free",
                                    fontWeight = FontWeight.Bold,
                                    color = if (deviceResources.isRamSufficient) StatusSuccess else StatusWarning,
                                    fontSize = 13.sp
                                )
                                Text("of ${deviceResources.totalRamMb} MB total", fontSize = 10.sp, color = TextMutedDark)
                            }
                        }

                        Surface(
                            color = CardDark,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("App Storage", style = MaterialTheme.typography.labelMedium, color = TextMutedDark)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    "${deviceResources.freeStorageMb / 1024} GB Free",
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimaryDark,
                                    fontSize = 13.sp
                                )
                                Text("App-private models dir", fontSize = 10.sp, color = TextMutedDark)
                            }
                        }
                    }
                }
            }

            // Import Button & Progress
            Surface(
                color = SurfaceDark,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, CardBorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Import Local GGUF Model",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark
                    )
                    Text(
                        text = "Select any .gguf file from your Downloads or file manager. Axiom AI will validate the header and copy it into private app storage.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondaryDark,
                        lineHeight = 20.sp
                    )

                    Button(
                        onClick = {
                            filePickerLauncher.launch(arrayOf("*/*"))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryViolet),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth(),
                        enabled = importProgress == null
                    ) {
                        Icon(imageVector = Icons.Default.FileOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Select GGUF File", fontWeight = FontWeight.SemiBold)
                    }

                    // Progress bar
                    if (importProgress != null) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            LinearProgressIndicator(
                                progress = { importProgress ?: 0f },
                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                                color = PrimaryViolet,
                                trackColor = CardDark
                            )
                            Text(
                                text = "Copying & validating GGUF model (${((importProgress ?: 0f) * 100).toInt()}%)...",
                                fontSize = 11.sp,
                                color = TextMutedDark
                            )
                        }
                    }
                }
            }

            // Installed Models List
            Text(
                text = "Installed On-Device Models",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = PrimaryViolet
            )

            if (installedModels.isEmpty()) {
                Surface(
                    color = StatusWarningBg,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, StatusWarning.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = StatusWarning, modifier = Modifier.size(18.dp))
                            Text(text = "No local model installed", fontWeight = FontWeight.Bold, color = StatusWarning)
                        }
                        Text(
                            text = "Please import a GGUF file or download one of the recommended small models below to start chatting completely offline.",
                            fontSize = 12.sp,
                            color = TextSecondaryDark,
                            lineHeight = 18.sp
                        )
                    }
                }
            } else {
                installedModels.forEach { model ->
                    val isActive = activeModel?.id == model.id
                    Surface(
                        color = SurfaceDark,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(
                            1.dp,
                            if (isActive) PrimaryViolet else CardBorderDark
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = model.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimaryDark
                                    )
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 2.dp)) {
                                        Text(model.sizeFormatted, fontSize = 11.sp, color = TextMutedDark)
                                        Text("·", fontSize = 11.sp, color = TextMutedDark)
                                        Text(model.quantType, fontSize = 11.sp, color = AccentPurpleLight, fontWeight = FontWeight.Medium)
                                    }
                                }

                                Surface(
                                    color = if (isActive) StatusSuccessBg else CardDark,
                                    shape = RoundedCornerShape(6.dp),
                                    border = BorderStroke(1.dp, if (isActive) StatusSuccess.copy(alpha = 0.4f) else CardBorderDark)
                                ) {
                                    Text(
                                        text = if (isActive) "ACTIVE" else "STANDBY",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isActive) StatusSuccess else TextMutedDark,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (isActive) {
                                    OutlinedButton(
                                        onClick = { viewModel.deactivateModel() },
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Deactivate")
                                    }
                                } else {
                                    Button(
                                        onClick = { viewModel.activateModel(model) },
                                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryViolet),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Load Model")
                                    }
                                }

                                IconButton(
                                    onClick = { modelToDelete = model },
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DeleteOutline,
                                        contentDescription = "Delete model",
                                        tint = Color(0xFFEF4444)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Recommended Models section
            Text(
                text = "Recommended for Vivo V25 (Dimensity 1300)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = PrimaryViolet
            )

            viewModel.recommendedModels.forEach { rec ->
                Surface(
                    color = SurfaceDark,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, CardBorderDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(rec.title, fontWeight = FontWeight.Bold, color = TextPrimaryDark)
                            Surface(
                                color = CardDark,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "${rec.sizeMb} MB · ${rec.quant}",
                                    fontSize = 10.sp,
                                    color = AccentPurpleLight,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(rec.description, fontSize = 12.sp, color = TextSecondaryDark, lineHeight = 18.sp)
                        Text(
                            text = "Download on phone from HuggingFace, then tap 'Select GGUF File' above to import.",
                            fontSize = 11.sp,
                            color = TextMutedDark
                        )
                    }
                }
            }
        }
    }

    // Delete Confirmation Dialog
    if (modelToDelete != null) {
        AlertDialog(
            onDismissRequest = { modelToDelete = null },
            title = { Text("Delete Model?", fontWeight = FontWeight.Bold, color = TextPrimaryDark) },
            text = {
                Text(
                    "Are you sure you want to remove ${modelToDelete?.name} (${modelToDelete?.sizeFormatted}) from your phone storage?",
                    color = TextSecondaryDark,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val m = modelToDelete
                        modelToDelete = null
                        if (m != null) viewModel.deleteModel(m)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { modelToDelete = null }) {
                    Text("Cancel")
                }
            },
            containerColor = SurfaceDark
        )
    }
}
