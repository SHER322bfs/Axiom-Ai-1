package com.axiomai.app.service

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

data class CapturedNotification(
    val packageName: String,
    val appTitle: String,
    val title: String,
    val text: String,
    val timestamp: Long
)

class AxiomNotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return

        val extras = sbn.notification.extras ?: return
        val title = extras.getString(Notification.EXTRA_TITLE) ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val pkg = sbn.packageName

        // Ignore our own notification
        if (pkg == packageName) return

        if (title.isNotEmpty() || text.isNotEmpty()) {
            val pm = packageManager
            val appTitle = try {
                val appInfo = pm.getApplicationInfo(pkg, 0)
                pm.getApplicationLabel(appInfo).toString()
            } catch (e: Exception) {
                pkg
            }

            synchronized(recentNotifications) {
                recentNotifications.add(
                    0,
                    CapturedNotification(
                        packageName = pkg,
                        appTitle = appTitle,
                        title = title,
                        text = text,
                        timestamp = sbn.postTime
                    )
                )
                if (recentNotifications.size > 20) {
                    recentNotifications.removeAt(recentNotifications.size - 1)
                }
            }
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {}

    companion object {
        private val recentNotifications = mutableListOf<CapturedNotification>()

        fun getRecentNotifications(): List<CapturedNotification> {
            synchronized(recentNotifications) {
                return recentNotifications.toList()
            }
        }

        fun clearNotifications() {
            synchronized(recentNotifications) {
                recentNotifications.clear()
            }
        }
    }
}
