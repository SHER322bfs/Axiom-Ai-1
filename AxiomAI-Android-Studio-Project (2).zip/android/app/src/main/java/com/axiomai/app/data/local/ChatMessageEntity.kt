package com.axiomai.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class MessageSender {
    USER,
    ASSISTANT,
    SYSTEM
}

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sender: MessageSender,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)
