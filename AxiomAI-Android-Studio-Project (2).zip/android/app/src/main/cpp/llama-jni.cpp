#include <jni.h>
#include <string>
#include <vector>
#include <memory>
#include <atomic>
#include <mutex>
#include <fstream>
#include <sstream>
#include <cstring>
#include <android/log.h>
#include <llama.h>

#define TAG "AxiomLlamaJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)

constexpr uint32_t GGUF_MAGIC = 0x46554747; // 'GGUF' little-endian

enum class GgufMetadataValueType : uint32_t {
    UINT8 = 0,
    INT8 = 1,
    UINT16 = 2,
    INT16 = 3,
    UINT32 = 4,
    INT32 = 5,
    FLOAT32 = 6,
    BOOL = 7,
    STRING = 8,
    ARRAY = 9,
    UINT64 = 10,
    INT64 = 11,
    FLOAT64 = 12,
};

struct GgufHeaderInfo {
    uint32_t version = 0;
    uint64_t tensor_count = 0;
    uint64_t metadata_kv_count = 0;
    std::string architecture = "unknown";
    std::string model_name = "unknown";
    uint64_t context_length = 2048;
    uint64_t block_count = 0;
    uint64_t embedding_length = 0;
    uint64_t file_size_bytes = 0;
    uint64_t estimated_ram_mb = 0;
    bool is_compatible = true;
    std::string error_msg = "";
};

// Global active model & context state
struct LlamaRuntime {
    llama_model * model = nullptr;
    llama_context * ctx = nullptr;
    llama_sampler * smpl = nullptr;
    std::string model_path;
    std::string model_name;
    int n_threads = 4;
    int context_size = 2048;
    std::atomic<bool> is_loaded{false};
    std::atomic<bool> stop_requested{false};
};

static std::unique_ptr<LlamaRuntime> g_runtime = nullptr;
static std::mutex g_runtime_mutex;

static std::string jstring2string(JNIEnv* env, jstring jStr) {
    if (!jStr) return "";
    const char* chars = env->GetStringUTFChars(jStr, nullptr);
    std::string str(chars);
    env->ReleaseStringUTFChars(jStr, chars);
    return str;
}

static bool read_gguf_string(std::ifstream& file, std::string& out_str) {
    uint64_t len = 0;
    if (!file.read(reinterpret_cast<char*>(&len), sizeof(len))) return false;
    if (len > 1024 * 1024) return false; // Sanity check max string length
    out_str.resize(len);
    if (!file.read(&out_str[0], len)) return false;
    return true;
}

static void skip_gguf_value(std::ifstream& file, GgufMetadataValueType type) {
    switch (type) {
        case GgufMetadataValueType::UINT8:
        case GgufMetadataValueType::INT8:
        case GgufMetadataValueType::BOOL:
            file.seekg(1, std::ios::cur);
            break;
        case GgufMetadataValueType::UINT16:
        case GgufMetadataValueType::INT16:
            file.seekg(2, std::ios::cur);
            break;
        case GgufMetadataValueType::UINT32:
        case GgufMetadataValueType::INT32:
        case GgufMetadataValueType::FLOAT32:
            file.seekg(4, std::ios::cur);
            break;
        case GgufMetadataValueType::UINT64:
        case GgufMetadataValueType::INT64:
        case GgufMetadataValueType::FLOAT64:
            file.seekg(8, std::ios::cur);
            break;
        case GgufMetadataValueType::STRING: {
            std::string temp;
            read_gguf_string(file, temp);
            break;
        }
        case GgufMetadataValueType::ARRAY: {
            uint32_t elem_type_raw = 0;
            uint64_t count = 0;
            file.read(reinterpret_cast<char*>(&elem_type_raw), sizeof(elem_type_raw));
            file.read(reinterpret_cast<char*>(&count), sizeof(count));
            auto elem_type = static_cast<GgufMetadataValueType>(elem_type_raw);
            for (uint64_t i = 0; i < count && file.good(); ++i) {
                skip_gguf_value(file, elem_type);
            }
            break;
        }
        default:
            break;
    }
}

static GgufHeaderInfo inspect_gguf_file(const std::string& path) {
    GgufHeaderInfo info;
    std::ifstream file(path, std::ios::binary);
    if (!file.is_open()) {
        info.is_compatible = false;
        info.error_msg = "Cannot open model file: " + path;
        return info;
    }

    uint32_t magic = 0;
    file.read(reinterpret_cast<char*>(&magic), sizeof(magic));
    if (magic != GGUF_MAGIC) {
        info.is_compatible = false;
        info.error_msg = "Invalid GGUF header magic signature";
        return info;
    }

    file.read(reinterpret_cast<char*>(&info.version), sizeof(info.version));
    if (info.version < 2 || info.version > 3) {
        info.is_compatible = false;
        info.error_msg = "Unsupported GGUF version (expected v2 or v3)";
        return info;
    }

    file.read(reinterpret_cast<char*>(&info.tensor_count), sizeof(info.tensor_count));
    file.read(reinterpret_cast<char*>(&info.metadata_kv_count), sizeof(info.metadata_kv_count));

    // Get total file size
    file.seekg(0, std::ios::end);
    info.file_size_bytes = file.tellg();
    file.seekg(24, std::ios::beg); // Rewind back to start of metadata KV pairs

    // Parse metadata key-value pairs
    for (uint64_t i = 0; i < info.metadata_kv_count && file.good(); ++i) {
        std::string key;
        if (!read_gguf_string(file, key)) break;

        uint32_t val_type_raw = 0;
        file.read(reinterpret_cast<char*>(&val_type_raw), sizeof(val_type_raw));
        auto val_type = static_cast<GgufMetadataValueType>(val_type_raw);

        if (key == "general.architecture" && val_type == GgufMetadataValueType::STRING) {
            read_gguf_string(file, info.architecture);
        } else if (key == "general.name" && val_type == GgufMetadataValueType::STRING) {
            read_gguf_string(file, info.model_name);
        } else if ((key.find(".context_length") != std::string::npos) &&
                   (val_type == GgufMetadataValueType::UINT32 || val_type == GgufMetadataValueType::UINT64)) {
            if (val_type == GgufMetadataValueType::UINT32) {
                uint32_t ctx = 0;
                file.read(reinterpret_cast<char*>(&ctx), sizeof(ctx));
                info.context_length = ctx;
            } else {
                file.read(reinterpret_cast<char*>(&info.context_length), sizeof(info.context_length));
            }
        } else if ((key.find(".block_count") != std::string::npos) &&
                   (val_type == GgufMetadataValueType::UINT32 || val_type == GgufMetadataValueType::UINT64)) {
            if (val_type == GgufMetadataValueType::UINT32) {
                uint32_t blk = 0;
                file.read(reinterpret_cast<char*>(&blk), sizeof(blk));
                info.block_count = blk;
            } else {
                file.read(reinterpret_cast<char*>(&info.block_count), sizeof(info.block_count));
            }
        } else if ((key.find(".embedding_length") != std::string::npos) &&
                   (val_type == GgufMetadataValueType::UINT32 || val_type == GgufMetadataValueType::UINT64)) {
            if (val_type == GgufMetadataValueType::UINT32) {
                uint32_t emb = 0;
                file.read(reinterpret_cast<char*>(&emb), sizeof(emb));
                info.embedding_length = emb;
            } else {
                file.read(reinterpret_cast<char*>(&info.embedding_length), sizeof(info.embedding_length));
            }
        } else {
            skip_gguf_value(file, val_type);
        }
    }

    // Estimate RAM required: model weights + KV cache overhead
    uint64_t model_mb = info.file_size_bytes / (1024 * 1024);
    uint64_t kv_cache_mb = 256; // typical KV cache size for 2048 ctx
    if (info.embedding_length > 0 && info.block_count > 0) {
        // 2 * n_layers * n_embd * n_ctx * 2 (fp16) bytes
        uint64_t raw_kv = 2ULL * info.block_count * info.embedding_length * 2048ULL * 2ULL;
        kv_cache_mb = raw_kv / (1024 * 1024);
    }
    info.estimated_ram_mb = model_mb + kv_cache_mb + 120; // 120MB llama.cpp workspace overhead

    // Vivo V25 budget: 8 GB RAM total, ~5.2 GB available for user space
    constexpr uint64_t VIVO_V25_RAM_BUDGET_MB = 5200;
    if (info.estimated_ram_mb > VIVO_V25_RAM_BUDGET_MB) {
        info.is_compatible = false;
        info.error_msg = "Model requires ~" + std::to_string(info.estimated_ram_mb) +
                         " MB RAM, exceeding the available ~5.2 GB budget of Vivo V25. Use Q4_K_M quant under 4GB.";
    }

    return info;
}

extern "C" {

// =========================================================================
// JNI BINDINGS FOR KOTLIN NativeLlamaBridge
// =========================================================================

JNIEXPORT jstring JNICALL
Java_com_axiomai_app_domain_engine_NativeLlamaBridge_nativeValidateGguf(
    JNIEnv* env,
    jobject /* this */,
    jstring jPath
) {
    std::string path = jstring2string(env, jPath);
    if (path.empty()) {
        return env->NewStringUTF("{\"valid\": false, \"error\": \"Empty file path\"}");
    }

    GgufHeaderInfo info = inspect_gguf_file(path);

    std::ostringstream json;
    json << "{"
         << "\"valid\": " << (info.is_compatible ? "true" : "false") << ","
         << "\"version\": " << info.version << ","
         << "\"architecture\": \"" << info.architecture << "\","
         << "\"modelName\": \"" << info.model_name << "\","
         << "\"tensorCount\": " << info.tensor_count << ","
         << "\"metadataCount\": " << info.metadata_kv_count << ","
         << "\"contextLength\": " << info.context_length << ","
         << "\"blockCount\": " << info.block_count << ","
         << "\"fileSizeBytes\": " << info.file_size_bytes << ","
         << "\"estimatedRamMb\": " << info.estimated_ram_mb << ","
         << "\"deviceBudgetRamMb\": 5200,"
         << "\"compatible\": " << (info.is_compatible ? "true" : "false");

    if (!info.is_compatible && !info.error_msg.empty()) {
        json << ",\"error\": \"" << info.error_msg << "\"";
    }
    json << "}";

    LOGI("Validated GGUF model: arch=%s, tensors=%llu, RAM est=%llu MB, compatible=%d",
         info.architecture.c_str(), info.tensor_count, info.estimated_ram_mb, info.is_compatible);

    return env->NewStringUTF(json.str().c_str());
}

JNIEXPORT jboolean JNICALL
Java_com_axiomai_app_domain_engine_NativeLlamaBridge_nativeLoadModel(
    JNIEnv* env,
    jobject /* this */,
    jstring jPath,
    jint nThreads,
    jint contextSize,
    jboolean useGpu
) {
    std::lock_guard<std::mutex> lock(g_runtime_mutex);
    std::string path = jstring2string(env, jPath);

    LOGI("nativeLoadModel starting for: %s (threads=%d, ctx=%d, GPU=%d)",
         path.c_str(), nThreads, contextSize, useGpu);

    // Free previously active model if any
    if (g_runtime) {
        if (g_runtime->smpl) llama_sampler_free(g_runtime->smpl);
        if (g_runtime->ctx) llama_free(g_runtime->ctx);
        if (g_runtime->model) llama_free_model(g_runtime->model);
        g_runtime = nullptr;
    }

    llama_backend_init();

    llama_model_params mparams = llama_model_default_params();
    mparams.n_gpu_layers = useGpu ? 16 : 0;
    mparams.use_mmap = true;
    mparams.use_mlock = false;
    mparams.check_tensors = true;

    llama_model * model = llama_load_model_from_file(path.c_str(), mparams);
    if (!model) {
        LOGE("llama_load_model_from_file failed to load: %s", path.c_str());
        return JNI_FALSE;
    }

    llama_context_params cparams = llama_context_default_params();
    cparams.n_ctx = contextSize > 0 ? contextSize : 2048;
    cparams.n_threads = nThreads > 0 ? nThreads : 4;
    cparams.n_threads_batch = cparams.n_threads;
    cparams.flash_attn = true;

    llama_context * ctx = llama_new_context_with_model(model, cparams);
    if (!ctx) {
        LOGE("llama_new_context_with_model failed to create context");
        llama_free_model(model);
        return JNI_FALSE;
    }

    llama_sampler_chain_params sparams = llama_sampler_chain_default_params();
    llama_sampler * smpl = llama_sampler_chain_init(sparams);
    llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist(1337));

    std::string filename = path;
    const size_t slash = path.find_last_of("/\\");
    if (slash != std::string::npos) filename = path.substr(slash + 1);

    g_runtime = std::make_unique<LlamaRuntime>();
    g_runtime->model = model;
    g_runtime->ctx = ctx;
    g_runtime->smpl = smpl;
    g_runtime->model_path = path;
    g_runtime->model_name = filename;
    g_runtime->n_threads = cparams.n_threads;
    g_runtime->context_size = cparams.n_ctx;
    g_runtime->is_loaded = true;
    g_runtime->stop_requested = false;

    LOGI("Model successfully loaded in llama.cpp native engine: %s", filename.c_str());
    return JNI_TRUE;
}

JNIEXPORT void JNICALL
Java_com_axiomai_app_domain_engine_NativeLlamaBridge_nativeUnloadModel(
    JNIEnv* /* env */,
    jobject /* this */
) {
    std::lock_guard<std::mutex> lock(g_runtime_mutex);
    if (g_runtime) {
        LOGI("Unloading model from native engine: %s", g_runtime->model_name.c_str());
        if (g_runtime->smpl) llama_sampler_free(g_runtime->smpl);
        if (g_runtime->ctx) llama_free(g_runtime->ctx);
        if (g_runtime->model) llama_free_model(g_runtime->model);
        g_runtime->is_loaded = false;
        g_runtime = nullptr;
        llama_backend_free();
    }
}

JNIEXPORT void JNICALL
Java_com_axiomai_app_domain_engine_NativeLlamaBridge_nativeStopGeneration(
    JNIEnv* /* env */,
    jobject /* this */
) {
    if (g_runtime) {
        LOGI("nativeStopGeneration requested");
        g_runtime->stop_requested = true;
    }
}

JNIEXPORT jboolean JNICALL
Java_com_axiomai_app_domain_engine_NativeLlamaBridge_nativeIsModelLoaded(
    JNIEnv* /* env */,
    jobject /* this */
) {
    return (g_runtime && g_runtime->is_loaded && g_runtime->ctx && g_runtime->model) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_axiomai_app_domain_engine_NativeLlamaBridge_nativeGenerateTokens(
    JNIEnv* env,
    jobject /* this */,
    jstring jPrompt,
    jobject jCallback
) {
    if (!g_runtime || !g_runtime->is_loaded || !g_runtime->ctx || !g_runtime->model) {
        LOGE("nativeGenerateTokens failed: No active llama model or context");
        return JNI_FALSE;
    }

    g_runtime->stop_requested = false;

    std::string prompt = jstring2string(env, jPrompt);
    jclass callbackClass = env->GetObjectClass(jCallback);
    if (!callbackClass) {
        LOGE("Could not locate callback class");
        return JNI_FALSE;
    }

    jmethodID onTokenMethod = env->GetMethodID(callbackClass, "onTokenGenerated", "(Ljava/lang/String;)V");
    if (!onTokenMethod) {
        LOGE("Callback method onTokenGenerated(String) not found");
        return JNI_FALSE;
    }

    const llama_vocab * vocab = llama_model_get_vocab(g_runtime->model);
    if (!vocab) {
        LOGE("Failed to obtain vocabulary from llama_model");
        return JNI_FALSE;
    }

    // Tokenize prompt
    std::vector<llama_token> prompt_tokens(g_runtime->context_size);
    int n_prompt_tokens = llama_tokenize(
        vocab,
        prompt.c_str(),
        prompt.length(),
        prompt_tokens.data(),
        prompt_tokens.size(),
        true, // add BOS special token
        true  // parse special tokens
    );

    if (n_prompt_tokens < 0) {
        prompt_tokens.resize(-n_prompt_tokens);
        n_prompt_tokens = llama_tokenize(
            vocab,
            prompt.c_str(),
            prompt.length(),
            prompt_tokens.data(),
            prompt_tokens.size(),
            true,
            true
        );
    }

    if (n_prompt_tokens <= 0) {
        LOGE("Prompt tokenization returned zero or invalid tokens");
        return JNI_FALSE;
    }

    if (n_prompt_tokens >= g_runtime->context_size) {
        LOGE("Prompt token count (%d) exceeds context window (%d)", n_prompt_tokens, g_runtime->context_size);
        return JNI_FALSE;
    }

    LOGI("Prompt tokenized into %d tokens. Starting llama_decode evaluation...", n_prompt_tokens);

    // Initialize batch for prompt evaluation
    llama_batch batch = llama_batch_init(g_runtime->context_size, 0, 1);
    for (int i = 0; i < n_prompt_tokens; i++) {
        batch.token[i] = prompt_tokens[i];
        batch.pos[i] = i;
        batch.n_seq_id[i] = 1;
        batch.seq_id[i][0] = 0;
        batch.logits[i] = (i == n_prompt_tokens - 1);
    }
    batch.n_tokens = n_prompt_tokens;

    if (llama_decode(g_runtime->ctx, batch) != 0) {
        LOGE("llama_decode failed during prompt prefill");
        llama_batch_free(batch);
        return JNI_FALSE;
    }

    int n_cur = n_prompt_tokens;
    int n_decode = 0;
    const int max_tokens = 512;
    char piece_buf[256];

    // Autoregressive token decoding loop
    while (n_decode < max_tokens && n_cur < g_runtime->context_size) {
        if (g_runtime->stop_requested) {
            LOGI("Inference stopped by user request at token %d", n_decode);
            break;
        }

        llama_token next_token = llama_sampler_sample(g_runtime->smpl, g_runtime->ctx, -1);
        llama_sampler_accept(g_runtime->smpl, next_token);

        if (llama_vocab_is_eog(vocab, next_token)) {
            LOGI("End of generation reached (EOG/EOS)");
            break;
        }

        int piece_len = llama_token_to_piece(vocab, next_token, piece_buf, sizeof(piece_buf), 0, false);
        if (piece_len > 0) {
            piece_buf[piece_len] = '\0';
            jstring jPiece = env->NewStringUTF(piece_buf);
            env->CallVoidMethod(jCallback, onTokenMethod, jPiece);
            env->DeleteLocalRef(jPiece);
        }

        // Prepare batch for next single token decode
        batch.n_tokens = 0;
        batch.token[0] = next_token;
        batch.pos[0] = n_cur;
        batch.n_seq_id[0] = 1;
        batch.seq_id[0][0] = 0;
        batch.logits[0] = true;
        batch.n_tokens = 1;

        n_cur++;
        n_decode++;

        if (llama_decode(g_runtime->ctx, batch) != 0) {
            LOGE("llama_decode failed at generation step %d", n_decode);
            break;
        }
    }

    llama_batch_free(batch);
    LOGI("Inference completed: %d tokens generated.", n_decode);
    return JNI_TRUE;
}

} // extern "C"
